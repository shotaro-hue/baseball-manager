import {cpuRosterPlan,assessCpuAddition} from './rosterPlanning';
import { clamp, rng } from '../utils';
import {
  ACCEPT_THRESHOLD, MIN_SALARY_SHIHAKA, MIN_SALARY_IKUSEI,
  ACTIVE_ROSTER_FA_DAYS_PER_YEAR,
  CPU_FA_BUDGET_RESERVE_RATIO, CPU_FA_MIN_SCORE,
  CPU_FA_REBUILD_YOUNG_BONUS, CPU_FA_REBUILD_OLD_PENALTY, CPU_FA_CONTEND_VET_BONUS,
  CPU_RENEWAL_ROUNDS,
  CPU_TEAM_ROUND2_GAP_CLOSE,
  PLAYER_RESISTANCE_HIGH_MORALE, PLAYER_RESISTANCE_LOW_MORALE,
  NEGOTIATION_MORALE_ACCEPT_BONUS, NEGOTIATION_MORALE_CUT_PENALTY,
  NEGOTIATION_MORALE_ROUND_HIT,
  NEGOTIATION_TRUST_HAPPY, NEGOTIATION_TRUST_HOLDOUT, NEGOTIATION_TRUST_RELEASED,
} from '../constants';
import { analyzeTeamNeeds, getFrontOfficePlanPublic } from './trade';
import { calculateSalaryDemand, renewalSalaryFloor } from './salaryDemand';
import { salaryCutRule, renewalEligible, ownedPlayers, ikuseiContractYears } from './renewalRules';
import { pruneRosterReferences } from './offseasonReview';
import { marketPlacement, marketRosterError } from './marketRoster';
import { prepareOffseasonFreeAgent } from './offseasonMarket';

/* ═══════════════════════════════════════════════
   FA 資格閾値 (NPB公式準拠・累積日数方式)
   高卒・外国人: 国内FA 960日 (8年×120) / 海外FA 1080日 (9年×120)
   大卒・社会人: 国内FA 840日 (7年×120) / 海外FA 1080日
   判定フィールド: daysOnActiveRoster（一軍在籍累積日数）
═══════════════════════════════════════════════ */
export function getFaThreshold(player) {
  const base = (['高卒', '高校生', '外国人'].includes(player.entryType)) ? 8 : 7;
  return {
    domestic: base * ACTIVE_ROSTER_FA_DAYS_PER_YEAR,
    overseas: 9 * ACTIVE_ROSTER_FA_DAYS_PER_YEAR,
  };
}

export function getFaProgress(player) {
  const measured = Number.isFinite(player.daysOnActiveRoster) && player.daysOnActiveRoster >= 0;
  const estimated = !measured && Number.isFinite(player.serviceYears) && player.serviceYears >= 0;
  if (!measured && !estimated) return { recorded: false };
  const days = measured ? player.daysOnActiveRoster : player.serviceYears * ACTIVE_ROSTER_FA_DAYS_PER_YEAR;
  const threshold = getFaThreshold(player);
  const progress = required => {
    const remainingDays = Math.max(0, required - days);
    return { remainingDays, years: Math.ceil(remainingDays / ACTIVE_ROSTER_FA_DAYS_PER_YEAR), eligible: remainingDays === 0 };
  };
  return { recorded: true, estimated, days, domestic: progress(threshold.domestic), overseas: progress(threshold.overseas) };
}

/* ═══════════════════════════════════════════════
   PLAYER DEMAND CALCULATION
   選手が要求する年俸・抵抗係数を算出する
═══════════════════════════════════════════════ */

export function calcPlayerDemand(player, context = {}) {
  const demand = calculateSalaryDemand(player, context);
  const money = player.personality?.money ?? 50;
  const morale = player.morale ?? 70;
  let resistance = .5;
  if (money >= 70) resistance += .15;
  if (morale >= PLAYER_RESISTANCE_HIGH_MORALE) resistance += .15;
  if (morale <= PLAYER_RESISTANCE_LOW_MORALE) resistance -= .2;
  if ((player.serviceYears ?? 0) >= 8) resistance += .1;
  return { ...demand, resistanceFactor: clamp(resistance, .1, .95) };
}

export function evaluateRenewalOffer(player, offer, team, teams, demand, round = 1) {
  const salary = Number(offer.salary);
  const years = Number(offer.years);
  const valid = offer.salary !== '' && Number.isFinite(salary) && salary > 0 && Number.isInteger(years) && years >= 1 && years <= 7;
  if (!valid) return { accepted: false, valid: false, score: null, reason: '年俸は正の金額、契約年数は1〜7年で入力してください' };
  if (player.育成 && years > ikuseiContractYears(player)) return { accepted: false, valid: false, score: null, reason: '育成3年満了までに収まる契約年数を選んでください' };
  const minimum = player.育成 ? MIN_SALARY_IKUSEI : MIN_SALARY_SHIHAKA;
  const cut = salaryCutRule(player, salary);
  const defaults = { money:50, winning:50, playing:50, hometown:30, loyalty:50, stability:50, future:50 };
  const normalized = { ...player, trust: player.trust ?? 50, personality: { ...defaults, ...player.personality } };
  const pitchScore = player.isPitcher
    ? ((team.rotation || []).includes(player.id) ? 85 : /中継ぎ|抑え|救援/.test(player.subtype || player.pos || '') ? 75 : 40)
    : undefined;
  const score = evalOffer(normalized, offer, team, teams, { referenceSalary: demand.demandSalary, playingScore: pitchScore }).total;
  const threshold = round === 1 ? ACCEPT_THRESHOLD + Math.round((demand.resistanceFactor ?? .5) * 20) : ACCEPT_THRESHOLD;
  const accepted = salary >= minimum && (salary >= demand.demandSalary || (salary >= (demand.minAcceptSalary ?? minimum) && score >= threshold));
  return { accepted, valid: true, score, threshold, cut, freeAgencyRequested: !accepted && cut.exceeds,
    reason: accepted ? (cut.exceeds ? '減額制限超過に同意して合意' : '合意') : salary < minimum ? `最低年俸保障（${minimum}万円）を下回るため合意できません` : cut.exceeds ? '減額制限超過に同意しません。制限内の条件を提示しない場合は自由契約を希望します' : '要求額・契約条件の再検討が必要です' };
}
/* ═══════════════════════════════════════════════
   MULTI-ROUND NEGOTIATION SIMULATION
   CPU球団と選手間の交渉を最大3ラウンドでシミュレートする
═══════════════════════════════════════════════ */

export function simulateNegotiationRounds(player, team, allTeams, demandSalary, resistanceFactor, demandDetails = {}) {
  const minAllowed = renewalSalaryFloor(player);
  const demand = { ...demandDetails, demandSalary, resistanceFactor, minOfferSalary: minAllowed };
  const threshold = getFaThreshold(player);
  const days      = player.daysOnActiveRoster ?? (player.serviceYears ?? 0) * ACTIVE_ROSTER_FA_DAYS_PER_YEAR;
  const isFA      = !player.育成 && days >= threshold.domestic;

  let budget      = team.budget;
  let moraleDelta = 0;
  let trustDelta  = 0;

  const initialOffer = Math.min(demandSalary, Math.max(minAllowed, Math.round(demandSalary * .85 / 100) * 100));
  const gap          = Math.max(0, demandSalary - initialOffer);

  for (let round = 1; round <= CPU_RENEWAL_ROUNDS; round++) {
    let offered;
    if      (round === 1) offered = initialOffer;
    else if (round === 2) offered = Math.min(demandSalary, Math.round((initialOffer + gap * CPU_TEAM_ROUND2_GAP_CLOSE) / 100) * 100);
    else                  offered = demandSalary;
    offered = clamp(offered, minAllowed, demandSalary);

    if (budget < offered) {
      return isFA
        ? { result: 'fa_declared', finalSalary: 0, years: 0, rounds: round, moraleDelta: -6, trustDelta: NEGOTIATION_TRUST_RELEASED }
        : { result: 'released',   finalSalary: 0, years: 0, rounds: round, moraleDelta: -10, trustDelta: NEGOTIATION_TRUST_RELEASED };
    }

    const evaluation = evaluateRenewalOffer(player, { salary: offered, years: 1 }, team, allTeams, demand, round);
    if (evaluation.accepted) {
      if (offered >= demandSalary)        moraleDelta += NEGOTIATION_MORALE_ACCEPT_BONUS;
      if (offered < player.salary * 0.90) moraleDelta += NEGOTIATION_MORALE_CUT_PENALTY;
      if (round > 1)                      moraleDelta += NEGOTIATION_MORALE_ROUND_HIT * (round - 1);
      trustDelta = round === 1 ? NEGOTIATION_TRUST_HAPPY : NEGOTIATION_TRUST_HOLDOUT;
      const years = Math.min(player.age <= 28 ? rng(1, 2) : 1, player.育成 ? ikuseiContractYears(player) : 7);
      return { result: 'signed', finalSalary: offered, years, rounds: round, moraleDelta, trustDelta };
    }
  }

  // No forced agreement: renewal acceptance always uses the shared evaluator.
  return {
    result: isFA ? 'fa_declared' : 'released',
    finalSalary: 0,
    years: 0,
    rounds: CPU_RENEWAL_ROUNDS,
    moraleDelta: -6,
    trustDelta: NEGOTIATION_TRUST_RELEASED,
  };
}

/* ═══════════════════════════════════════════════
   CONTRACT EVALUATION
═══════════════════════════════════════════════ */

export function evalOffer(player, offer, myTeam, allTeams, options = {}) {
  const p = player.personality || { money:50, winning:50, playing:50, hometown:30, loyalty:50, stability:50, future:50 };
  const g = myTeam.wins + myTeam.losses;
  const winPct = g > 0 ? myTeam.wins / g : 0.5;
  const rank = [...allTeams]
    .filter((t) => t.league === myTeam.league)
    .sort((a, b) => b.wins - a.wins)
    .findIndex((t) => t.id === myTeam.id) + 1;

  const moneyScore = clamp((offer.salary / Math.max(options.referenceSalary ?? player.salary, MIN_SALARY_SHIHAKA)) * 60 + 20, 0, 100);
  const winScore = clamp(winPct * 100 * 1.2, 0, 100);
  const rankScore = clamp((7 - rank) / 6 * 100, 0, 100);
  const playScore = options.playingScore ?? ((myTeam.lineup || []).includes(player.id) ? 85 : 40);
  const homeScore = myTeam.city === player.hometown ? 80 : 30;
  const trustScore = clamp(player.trust, 0, 100);
  const avgAge = myTeam.players.reduce((s, x) => s + x.age, 0) / Math.max(myTeam.players.length, 1);
  const futureScore = clamp((32 - avgAge) / 14 * 100, 0, 100);
  const stabilityScore = offer.years >= 3 ? 85 : offer.years === 2 ? 65 : 40;
  const incentives = offer.incentives || {};
  const performanceBonusRate = clamp(Number(incentives.performanceBonusRate) || 0, 0, 30);
  const titleBonus = clamp(Number(incentives.titleBonus) || 0, 0, 3000);
  const optOut = Boolean(incentives.optOut);
  const incentiveScore = clamp(
    performanceBonusRate * 3 + Math.min(35, titleBonus / 35) + (optOut ? 22 : 0),
    0,
    100,
  );
  const incentiveWeight = Math.max(15, Math.round((p.money + p.future) / 4));

  const total = (
    p.money * moneyScore +
    p.winning * Math.max(winScore, rankScore) +
    p.playing * playScore +
    p.hometown * homeScore +
    p.loyalty * trustScore +
    p.stability * stabilityScore +
    p.future * futureScore +
    incentiveWeight * incentiveScore
  ) / (p.money + p.winning + p.playing + p.hometown + p.loyalty + p.stability + p.future + incentiveWeight);

  return {
    total: Math.round(total),
    breakdown: {
      money:     { score: Math.round(moneyScore), weight: p.money },
      winning:   { score: Math.round(Math.max(winScore, rankScore)), weight: p.winning },
      playing:   { score: Math.round(playScore), weight: p.playing },
      hometown:  { score: Math.round(homeScore), weight: p.hometown },
      loyalty:   { score: Math.round(trustScore), weight: p.loyalty },
      stability: { score: Math.round(stabilityScore), weight: p.stability },
      future:    { score: Math.round(futureScore), weight: p.future },
      incentive: { score: Math.round(incentiveScore), weight: incentiveWeight },
    },
  };
}

/* ═══════════════════════════════════════════════
   CPU CONTRACT RENEWAL
   オフシーズンに CPU 球団が満了選手と再契約する
═══════════════════════════════════════════════ */

export function cpuRenewContracts(teams, myId, allTeams, salaryContext = {}) {
  const updatedTeams = [];
  const newFaPlayers = [];
  const news = [];

  for (const t of teams) {
    if (t.id === myId) { updatedTeams.push(t); continue; }

    const expiring = ownedPlayers(t).filter(p => renewalEligible(p, salaryContext.year));
    const farmIds = new Set((t.farm || []).map(p => p.id));
    let players = ownedPlayers(t);
    let budget = t.budget;

    for (const p of expiring) {
      const threshold = getFaThreshold(p);
      const days = p.daysOnActiveRoster ?? (p.serviceYears ?? 0) * ACTIVE_ROSTER_FA_DAYS_PER_YEAR;
      const overseas = p.personality?.overseas || 0;

      // 海外志向かつ海外FA資格あり: NPB離脱（変更なし）
      if (!p.育成 && overseas >= 70 && days >= threshold.overseas) {
        players = players.filter(x => x.id !== p.id);
        news.push({
          type: 'season',
          headline: `【海外FA】${p.name}（${t.name}）が海外移籍を宣言`,
          source: '野球速報',
          dateLabel: '',
          body: `${p.name}選手（${p.age}歳）が海外FA権を行使し、NPBを離脱した。`,
        });
        continue;
      }

      // 海外志向かつ国内FA資格はあるが海外FA資格なし: 国内FAをスキップして待機（変更なし）
      if (!p.育成 && overseas >= 70 && days < threshold.overseas) {
        const salary = Math.max(p.育成 ? MIN_SALARY_IKUSEI : MIN_SALARY_SHIHAKA, Math.round(p.salary * 1.03));
        if (budget >= salary) {
          players = players.map(x => x.id === p.id
            ? { ...x, salary, contractYears: 1, contractYearsLeft: 1, contractSignedYear: salaryContext.year }
            : x
          );
          budget -= salary;
        } else {
          players = players.filter(x => x.id !== p.id);
          newFaPlayers.push({ ...p, isFA: true, marketEntryReason: '自由契約' });
        }
        continue;
      }

      // 非FA / FA資格あり: マルチラウンド交渉シミュレーション
      const demand = calcPlayerDemand(p, { ...salaryContext, team: t, teams: allTeams });
      const neg = simulateNegotiationRounds(p, { ...t, budget }, allTeams, demand.demandSalary, demand.resistanceFactor, demand);

      if (neg.result === 'signed') {
        players = players.map(x => x.id === p.id ? {
          ...x,
          salary: neg.finalSalary,
          contractYears: neg.years,
          contractYearsLeft: neg.years,
          contractSignedYear: salaryContext.year,
          morale: clamp((x.morale ?? 70) + neg.moraleDelta, 20, 100),
          trust:  clamp((x.trust  ?? 50) + neg.trustDelta,  0, 100),
        } : x);
        budget -= neg.finalSalary;
      } else {
        players = players.filter(x => x.id !== p.id);
        const declared = neg.result === 'fa_declared';
        newFaPlayers.push({ ...p, isFA: true, contractYearsLeft: 0,
          ...(declared ? { salary: demand.demandSalary, faPreviousSalary: p.salary,
            faNegotiationReason: '契約更改で合意できなかったため' } : {}),
          marketEntryReason: declared ? '国内FA宣言' : '自由契約' });
        if (neg.result === 'fa_declared') {
          news.push({
            type: 'season',
            headline: `【FA】${p.name}（${t.name}）が国内FA宣言`,
            source: '野球速報',
            dateLabel: '',
            body: `${p.name}選手（${p.age}歳）が国内FA権を行使した。`,
          });
        } else {
          news.push({
            type: 'season',
            headline: `【戦力外】${p.name}（${t.name}）が自由契約`,
            source: '野球速報',
            dateLabel: '',
            body: `${p.name}選手（${p.age}歳）が${t.name}を自由契約となった。`,
          });
        }
      }
    }

    const removed = new Set(ownedPlayers(t).filter(p => !players.some(x => x.id === p.id)).map(p => p.id));
    updatedTeams.push({ ...t, players: players.filter(p => !farmIds.has(p.id)), farm: players.filter(p => farmIds.has(p.id)), budget, ...pruneRosterReferences(t, removed) });
  }

  return { updatedTeams, newFaPlayers, news };
}

/* ═══════════════════════════════════════════════
   CPU FA BIDDING
   ウェーバー後に CPU 球団が FA 市場で獲得する
═══════════════════════════════════════════════ */

/**
 * 選手がチームの補強ニーズにどれだけ合致するかをスコア化する。
 * @param {object} player
 * @param {Array<{type: string, score: number}>} needs
 * @returns {number}
 */
function calcNeedMatch(player, needs) {
  let bonus = 0;
  for (const n of needs) {
    if (n.type.includes('先発') && player.isPitcher && player.subtype === '先発') bonus += n.score;
    else if (n.type.includes('抑え') && player.isPitcher && player.subtype === '抑え') bonus += n.score;
    else if (n.type.includes('中継ぎ') && player.isPitcher && player.subtype === '中継ぎ') bonus += n.score;
    else if (n.type.includes('球威') && player.isPitcher) bonus += n.score * 0.5;
    else if (n.type.includes('捕手') && !player.isPitcher && player.pos === '捕手') bonus += n.score;
    else if (n.type.includes('ミート') && !player.isPitcher) bonus += n.score * 0.5;
    else if (n.type.includes('若手') && (player.age || 25) <= 26) bonus += n.score * 0.5;
    else if (n.type.includes('バランス')) bonus += 5;
  }
  return bonus;
}

export function processCpuFaBids(teams, myId, faPool, allTeams, currentYear = null, marketMode = 'season', draftContext = {}) {
  if (!faPool.length) return { updatedTeams: teams, remainingFaPool: faPool, news: [] };

  const news = [];
  let remainingPool = [...faPool];
  const teamMap = new Map(
    teams.map((t) => [t.id, { ...t, players: [...t.players], farm: [...(t.farm || [])] }]),
  );
  const claimed = [];
  const signedPlayers = new Set();

  const cpuTeams = teams
    .filter((t) => t.id !== myId)
    .sort((a, b) => b.budget - a.budget);

  const phase=marketMode==='offseason'?'offseason':'season';
  const rosterPlans=new Map(cpuTeams.map(t=>[t.id,cpuRosterPlan(t,{...draftContext,phase})]));
  let changed = true;
  while (changed && remainingPool.length > 0) {
    changed = false;

    for (const origTeam of cpuTeams) {
      const team = teamMap.get(origTeam.id);
      if (!team) continue;

      if (!Number.isFinite(team.budget)) continue;
      const reserve = team.budget * CPU_FA_BUDGET_RESERVE_RATIO;
      if (team.budget - reserve < MIN_SALARY_IKUSEI) continue;

      const needs = analyzeTeamNeeds(team);
      const plan = getFrontOfficePlanPublic(team);
      const foMode = plan.mode;
      const candidates = remainingPool
        .filter((p) => !signedPlayers.has(p.id) && !marketRosterError(team, p, [...teamMap.values()], draftContext))
        .map((p) => {
          if (!Number.isFinite(p.salary) || p.salary < 0) return null;
          const salary = Math.max(p.育成 ? MIN_SALARY_IKUSEI : MIN_SALARY_SHIHAKA, p.salary);
          if (team.budget - reserve < salary) return null;
          const rosterDecision=assessCpuAddition(team,p,{...draftContext,phase,teams:[...teamMap.values()],rosterPlan:rosterPlans.get(team.id),salary});
          if(!rosterDecision.eligible)return null;
          const r = evalOffer(p, { salary, years: 1 }, team, allTeams);
          const needBonus = calcNeedMatch(p, needs);
          let modeBonus = 0;
          if (foMode === 'rebuild') {
            if ((p.age || 25) <= 25) modeBonus += CPU_FA_REBUILD_YOUNG_BONUS;
            if ((p.age || 25) >= 32) modeBonus -= CPU_FA_REBUILD_OLD_PENALTY;
          } else if (foMode === 'contend') {
            if ((p.age || 25) >= 29) modeBonus += CPU_FA_CONTEND_VET_BONUS;
          }
          return { pid: p.id, score: r.total + needBonus * 0.3 + modeBonus, salary, rosterDecision };
        })
        .filter((c) => c && c.score >= CPU_FA_MIN_SCORE)
        .sort((a, b) => b.score - a.score);

      if (!candidates.length) continue;

      const best = candidates[0];
      const player = remainingPool.find((p) => p.id === best.pid);
      if (!player) continue;

      const goToFarm = marketPlacement(team, player).farm;

      const prepared = marketMode === 'offseason' ? prepareOffseasonFreeAgent(player, currentYear, team.id) : player;
      const newPlayerEntry = { ...prepared, isFA: false, contractYears: 1, contractYearsLeft: 1, contractSignedYear: currentYear, salary: best.salary,
        ...(player.育成 && player.departureReason === 'ikusei_expiry' ? { ikuseiYears: 0 } : {}) };
      const acquireReason = player.isForeign ? '外国人獲得' : (player.isWaiverReleased ? '戦力外獲得' : 'FA獲得');
      const historyRecord = { ...newPlayerEntry, exitYear: currentYear ?? 0, exitReason: acquireReason, tenure: 0,rosterDecision:best.rosterDecision.reason };
      rosterPlans.set(team.id,{...rosterPlans.get(team.id),draftRemaining:best.rosterDecision.draftRemaining});

      if (goToFarm) {
        teamMap.set(team.id, {
          ...team,
          farm: [...(team.farm || []), newPlayerEntry],
          budget: team.budget - best.salary,
          history: [...(team.history || []), historyRecord],
        });
      } else {
        teamMap.set(team.id, {
          ...team,
          players: [...team.players, newPlayerEntry],
          budget: team.budget - best.salary,
          history: [...(team.history || []), historyRecord],
        });
      }

      remainingPool = remainingPool.filter((p) => p.id !== best.pid);
      signedPlayers.add(best.pid);
      claimed.push({ player, teamName: team.name, teamEmoji: team.emoji, teamId: team.id,rosterDecision:best.rosterDecision.reason,projectedCount:best.rosterDecision.projectedCount });
      changed = true;

      news.push({
        type: 'season',
        headline: `【入団】${player.name}が${team.name}と契約`,
        source: '野球速報',
        dateLabel: '',
        body: `${player.name}選手（${player.age}歳）が${team.name}と契約した。`,
      });
    }
  }

  return {
    updatedTeams: teams.map((t) => teamMap.get(t.id) || t),
    remainingFaPool: remainingPool,
    news,
    claimed,
  };
}
