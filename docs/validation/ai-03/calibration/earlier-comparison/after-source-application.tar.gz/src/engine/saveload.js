import { validateFarmSaveState } from './farmMigration';
import { GENERATION_VERSION, LEGACY_GENERATION_VERSION, prepareGeneration, readGeneration, readCareerGeneration, collectUnusedChunks } from './saveGenerations';
import { prepareCareerData, captureInlineCareerLogs } from './careerGenerations';
import { MATCH_HISTORY_FIELDS, matchHistorySnapshot, matchHistoryForSave } from './matchHistory';
import LZString from 'lz-string';
import { resolveInitialContractYears } from './realplayer';
import {
  BASEBALL_MANAGER_DB_STORES,
  openBaseballManagerDb,
} from './baseballManagerDb';
import { ensureSaveId } from './saveIdentity';
import { MAX_BATTED_BALL_EVENTS, MAX_SPRAY_POINTS } from '../constants';
import {
  createEmptyBattedBallProfile,
  createRecentBattedBallProfile,
  updateBattedBallProfile,
} from './battedBallProfile';
import { hasSelectedTeam } from './teamId';
import { emptyStats } from './playerCore';
import {
  buildCareerLogSummary,
  getCareerEntryKey,
  getRecentCareerLog,
  normalizeCareerLogSummary,
} from './careerStats';

/* ═══════════════════════════════════════════════
   SAVE / LOAD — localStorage
═══════════════════════════════════════════════ */

const SAVE_KEY     = 'baseball_manager_v1';
const META_KEY     = 'baseball_manager_v1_meta';
const BACKUP_KEY_1 = 'baseball_manager_v1_bk1';
const BACKUP_KEY_2 = 'baseball_manager_v1_bk2';
const isDevEnv = import.meta.env?.DEV ?? false;
const PERF_LOG_KEY = 'baseball_manager_save_perf_logs';
const MAX_PERF_LOGS = 30;
const BACKUP_ROTATE_INTERVAL_MS = 5 * 60 * 1000;
const AUTO_SAVE_INTERVAL_MS = 60 * 1000;
const LAST_BACKUP_ROTATE_KEY = 'baseball_manager_v1_last_rotate_at';
const SAVE_SIZE_DEBUG_KEY = 'baseball_manager_debug_save_size';
const SAVE_DATA_VERSION = GENERATION_VERSION;
const INDEXED_DB_LARGE_DATA_VERSION = 3;
const IDB_STORES = {
  chunks: BASEBALL_MANAGER_DB_STORES.chunks,
  careerLogs: BASEBALL_MANAGER_DB_STORES.careerLogs,
};
const INDEXED_DB_CHUNK_SCOPES = ['seasonHistory', 'news', 'mailbox', 'matchHistory'];

const MAX_RECENT_CAREER_LOG_YEARS = 3;

export function createSaveRequestQueue(saveImpl) {
  let isSaving = false;
  let queuedPayload = null;
  let queuedListeners = [];
  const inheritOptions = (older, newer) => {
    const a=older.options.dirtyScopes,b=newer.options.dirtyScopes;
    const options={...newer.options,dirtyScopes:Array.isArray(a)&&Array.isArray(b)?[...new Set([...a,...b])]:undefined};
    if(older.state?.saveId===newer.state?.saveId && !(Number(newer.state?.year)<Number(older.state?.year))) {
      options.careerEntries=[...(older.options.careerEntries || []),...(newer.options.careerEntries || [])];
      if(options.initialCareerLogs===undefined && older.options.initialCareerLogs!==undefined) options.initialCareerLogs=older.options.initialCareerLogs;
    }
    return {...newer,options};
  };

  const runSave = async (payload, listeners = []) => {
    isSaving = true;
    let succeeded = false;
    try {
      const result = await saveImpl(payload);
      succeeded = result?.ok !== false;
      listeners.forEach(({ resolve }) => resolve(result));
      return result;
    } catch (error) {
      listeners.forEach(({ reject }) => reject(error));
      throw error;
    } finally {
      isSaving = false;
      if (queuedPayload !== null) {
        let nextPayload = queuedPayload;
        if (!succeeded && payload?.options && nextPayload?.options) {
          nextPayload = inheritOptions(payload,nextPayload);
        }
        const nextListeners = queuedListeners;
        queuedPayload = null;
        queuedListeners = [];
        void runSave(nextPayload, nextListeners).catch(() => {});
      }
    }
  };

  return {
    enqueue(payload) {
      if (!isSaving && queuedPayload === null) {
        return runSave(payload);
      }
      return new Promise((resolve, reject) => {
        if (queuedPayload?.options && payload?.options) {
          payload = inheritOptions(queuedPayload,payload);
        }
        queuedPayload = payload;
        queuedListeners.push({ resolve, reject });
      });
    },
    getSnapshot() {
      return {
        isSaving,
        hasQueuedSave: queuedPayload !== null,
      };
    },
  };
}

function sanitizeNumber(value, fallback = 0) {
  const safeFallback = Number.isFinite(Number(fallback)) ? Number(fallback) : 0;
  const normalized = Number(value);
  return Number.isFinite(normalized) ? normalized : safeFallback;
}

function sanitizeYear(value) {
  const normalized = Math.trunc(sanitizeNumber(value, 0));
  if (!Number.isFinite(normalized) || normalized < 0 || normalized > 9999) return 0;
  return normalized;
}

function isSaveSizeDebugEnabled() {
  if (!isDevEnv) return false;
  try {
    return localStorage.getItem(SAVE_SIZE_DEBUG_KEY) === '1';
  } catch {
    return false;
  }
}

function logPerf(label, startedAt) {
  if (!isDevEnv || !Number.isFinite(startedAt)) return;
  const elapsedMs = performance.now() - startedAt;
  console.log(`[Perf] ${label}: ${elapsedMs.toFixed(1)}ms`);
}

function appendSavePerfLog(log) {
  if (!isDevEnv || !log || typeof log !== 'object') return;
  try {
    const raw = localStorage.getItem(PERF_LOG_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    const logs = Array.isArray(parsed) ? parsed : [];
    logs.push(log);
    const limited = logs.slice(-MAX_PERF_LOGS);
    localStorage.setItem(PERF_LOG_KEY, JSON.stringify(limited));
  } catch (e) {
    console.warn('Save perf log write failed:', e);
  }
}

function safeElapsedMs(startedAt) {
  if (!isDevEnv || !Number.isFinite(startedAt)) return 0;
  return performance.now() - startedAt;
}

// ── バックアップローテーション ──────────────────
// 保存前に呼ぶ: bk1→bk2, 現在→bk1
function rotateBk(cur) {
  try {
    const bk1 = localStorage.getItem(BACKUP_KEY_1);
    if (bk1) localStorage.setItem(BACKUP_KEY_2, bk1);
    if (cur) localStorage.setItem(BACKUP_KEY_1, cur);
    localStorage.setItem(LAST_BACKUP_ROTATE_KEY, String(Date.now()));
    return true;
  } catch (e) {
    console.warn('Backup rotation failed:', e);
    return false;
  }
}

function shouldRotateBackupNow() {
  const lastRotateRaw = localStorage.getItem(LAST_BACKUP_ROTATE_KEY);
  const lastRotateAt = Number(lastRotateRaw);
  if (!Number.isFinite(lastRotateAt) || lastRotateAt <= 0) return true;
  return Date.now() - lastRotateAt >= BACKUP_ROTATE_INTERVAL_MS;
}

// ── 選手フィールドのマイグレーション ──────────────
function migratePlayer(p) {
  const legacyCareerLog = Array.isArray(p.careerLog) ? p.careerLog : [];
  const recentCareerLog = getRecentCareerLog(
    Array.isArray(p.recentCareerLog) ? p.recentCareerLog : legacyCareerLog,
    MAX_RECENT_CAREER_LOG_YEARS,
  );
  const legacyBattedBallEvents = Array.isArray(p?.stats?.battedBallEvents)
    ? p.stats.battedBallEvents.slice(-MAX_BATTED_BALL_EVENTS)
    : [];
  const migratedProfile = p?.stats?.battedBallProfile && typeof p.stats.battedBallProfile === 'object'
    ? { ...createEmptyBattedBallProfile(), ...p.stats.battedBallProfile }
    : legacyBattedBallEvents.reduce(
      (profile, event) => updateBattedBallProfile(profile, event),
      createEmptyBattedBallProfile(),
    );
  migratedProfile.recent = createRecentBattedBallProfile(legacyBattedBallEvents);
  const migratedStats = {
    ...emptyStats(),
    ...(p.stats ?? {}),
    sprayPoints: Array.isArray(p?.stats?.sprayPoints)
      ? p.stats.sprayPoints.slice(-MAX_SPRAY_POINTS)
      : [],
    battedBallEvents: legacyBattedBallEvents,
    battedBallProfile: migratedProfile,
  };
  return {
    ...p,
    entryAge:           p.entryAge           ?? p.age,
    serviceYears:       p.serviceYears       ?? 0,
    ikuseiYears:        p.ikuseiYears        ?? 0,
    condition:          p.condition          ?? 100,
    form:               p.form               ?? 50,
    morale:             p.morale             ?? 60,
    trust:              p.trust              ?? 50,
    injuryDaysLeft:     p.injuryDaysLeft     ?? 0,
    growthPhase:        p.growthPhase        ?? 'peak',
    recentPitchingDays: p.recentPitchingDays ?? [],
    careerLog:          [],
    recentCareerLog,
    trimmedCareerLogSummary: normalizeCareerLogSummary(p.trimmedCareerLogSummary ?? p.careerLogSummary ?? buildCareerLogSummary(legacyCareerLog)),
    careerLogSummary:   normalizeCareerLogSummary(p.trimmedCareerLogSummary ?? p.careerLogSummary ?? buildCareerLogSummary(legacyCareerLog)),
    peakAbilities:      p.peakAbilities      ?? null,
    stats:              migratedStats,
    playoffStats:       { ...emptyStats(), ...(p.playoffStats ?? {}) },
    stats2:             p.stats2             ?? { PA:0, H:0, HR:0, W:0, IP:0, ER:0, K:0 },
    entryType:          p.entryType          ?? (p.isForeign ? '外国人' : (p.entryAge??p.age) <= 19 ? '高卒' : (p.entryAge??p.age) <= 22 ? '大卒' : '社会人'),
    daysOnActiveRoster: p.daysOnActiveRoster ?? (p.serviceYears ?? 0) * 120,
  };
}

// ── セーブデータのバリデーション＆マイグレーション ──


function shouldFixInitialContractInSave(state) {
  const safeYear = Number(state?.year);
  const safeDay = Number(state?.gameDay);
  return Number.isFinite(safeYear) && safeYear === 2026 && Number.isFinite(safeDay) && safeDay <= 1;
}

function migrateInitialContractYears(player, teamName, state) {
  if (!shouldFixInitialContractInSave(state)) return player;
  if (!player || typeof player !== 'object') return player;

  const currentYears = Number(player.contractYears ?? 1);
  const currentLeft = Number(player.contractYearsLeft ?? 1);
  const isSingleYear = currentYears <= 1 && currentLeft <= 1;
  if (!isSingleYear) return player;

  const resolvedYears = resolveInitialContractYears(teamName, player.name);
  if (!Number.isFinite(resolvedYears) || resolvedYears <= 1) return player;

  return {
    ...player,
    contractYears: resolvedYears,
    contractYearsLeft: resolvedYears,
  };
}

function validateAndMigrateSave(state) {
  if (!state || !hasSelectedTeam(state.teams, state.myId) || !state.year) {
    return { ok: false };
  }
  // Introduced data is validated as-is; a corrupt ledger must reach backup recovery.
  validateFarmSaveState(state);
  const teams = state.teams.map(t => ({
    ...t,
    wins:               t.wins               ?? 0,
    losses:             t.losses             ?? 0,
    budget:             t.budget             ?? 5000,
    pitchingPattern:    t.pitchingPattern    ?? {},
    stadiumLevel:       t.stadiumLevel       ?? 0,
    revenueThisSeason:  t.revenueThisSeason  ?? 0,
    players: Array.isArray(t.players) ? t.players.map(migratePlayer).map(p => migrateInitialContractYears(p, t.name, state)) : [],
  }));
  return { ok: true, state: { ...state, ...matchHistorySnapshot(state), saveId: ensureSaveId(state.saveId), teams } };
}

function sanitizeSaveState(state) {
  if (!state || typeof state !== 'object' || !Array.isArray(state.teams)) {
    throw new Error('Invalid state for saving');
  }
  const {
    seasonHistory, news, mailbox,
    saveRevision,
    ...rest
  } = state;
  const teams = state.teams.map((team) => ({
    ...team,
    players: Array.isArray(team?.players) ? team.players.map((p) => ({
      ...p,
      careerLog: [],
      recentCareerLog: normalizeRecentCareerLog(p),
      stats: {
        ...(p.stats || {}),
        sprayPoints: Array.isArray(p?.stats?.sprayPoints)
          ? p.stats.sprayPoints.slice(-MAX_SPRAY_POINTS)
          : [],
        battedBallEvents: Array.isArray(p?.stats?.battedBallEvents)
          ? p.stats.battedBallEvents.slice(-MAX_BATTED_BALL_EVENTS)
          : [],
      },
    })) : [],
    farm: Array.isArray(team?.farm) ? team.farm.map((p) => ({
      ...p,
      careerLog: [],
      recentCareerLog: normalizeRecentCareerLog(p),
      stats: {
        ...(p.stats || {}),
        sprayPoints: Array.isArray(p?.stats?.sprayPoints)
          ? p.stats.sprayPoints.slice(-MAX_SPRAY_POINTS)
          : [],
        battedBallEvents: Array.isArray(p?.stats?.battedBallEvents)
          ? p.stats.battedBallEvents.slice(-MAX_BATTED_BALL_EVENTS)
          : [],
      },
    })) : [],
  }));
  return { ...rest, teams, seasonHistory, news, mailbox, saveRevision: sanitizeNumber(saveRevision, 0) };
}

function formatJsonSize(byteSize) {
  if (!Number.isFinite(byteSize) || byteSize < 0) return '0B';
  if (byteSize >= 1024 * 1024) return `${(byteSize / (1024 * 1024)).toFixed(2)}MB`;
  if (byteSize >= 1024) return `${(byteSize / 1024).toFixed(2)}KB`;
  return `${Math.round(byteSize)}B`;
}

function getJsonByteSize(value) {
  try {
    const serializedValue = JSON.stringify(value);
    if (typeof serializedValue !== 'string') return 0;
    return new TextEncoder().encode(serializedValue).length;
  } catch (e) {
    if (isSaveSizeDebugEnabled()) console.warn('[SaveSize] JSONサイズ計測に失敗しました:', e);
    return -1;
  }
}


function collectObjectFieldSizes(target, fieldNames) {
  const fieldSizes = [];
  fieldNames.forEach((fieldName) => {
    const fieldValue = target?.[fieldName];
    const byteSize = getJsonByteSize(fieldValue);
    if (byteSize >= 0) fieldSizes.push({ key: fieldName, byteSize });
  });
  return fieldSizes;
}

function summarizeTopObjectFields(target, limit = 5) {
  if (!target || typeof target !== 'object' || Array.isArray(target)) return [];
  return Object.keys(target)
    .map((key) => ({ key, byteSize: getJsonByteSize(target[key]) }))
    .filter((entry) => entry.byteSize >= 0)
    .sort((a, b) => b.byteSize - a.byteSize)
    .slice(0, limit);
}

function logTeamsBreakdownSize(state) {
  if (!isSaveSizeDebugEnabled() || !state || !Array.isArray(state.teams)) return;
  const teamsTotalSize = getJsonByteSize(state.teams);
  if (teamsTotalSize >= 0) {
    console.info(`[SaveSize:teams] total: ${formatJsonSize(teamsTotalSize)}`);
  }

  state.teams.forEach((team) => {
    if (!team || typeof team !== 'object') return;
    const teamName = team.name ?? 'Unknown';
    const teamId = team.id ?? 'unknown';
    const teamSize = getJsonByteSize(team);
    console.info(`[SaveSize:team] id=${teamId} name=${teamName} total=${formatJsonSize(teamSize)}`);

    const targetTeamFields = [
      'players', 'farm', 'lineup', 'lineupDh', 'lineupNoDh', 'rotation',
      'pitchingPattern', 'coaches', 'staff', 'contracts', 'stats', 'gameLogs',
      'resultLogs', 'results', 'matchLogs', 'gameResultLogs',
    ];
    const knownFieldSizes = collectObjectFieldSizes(team, targetTeamFields);
    const knownFieldKeys = new Set(targetTeamFields);
    const unknownLargeFields = Object.keys(team)
      .filter((key) => !knownFieldKeys.has(key))
      .map((key) => ({ key, byteSize: getJsonByteSize(team[key]) }))
      .filter((entry) => entry.byteSize >= 50 * 1024)
      .sort((a, b) => b.byteSize - a.byteSize)
      .slice(0, 8);

    const safeTeamSize = teamSize > 0 ? teamSize : 1;
    const teamFieldSummary = knownFieldSizes
      .sort((a, b) => b.byteSize - a.byteSize)
      .map((entry) => `${entry.key}=${formatJsonSize(entry.byteSize)}(${((entry.byteSize / safeTeamSize) * 100).toFixed(1)}%)`)
      .join(' ');
    const unknownSummary = unknownLargeFields.length > 0
      ? unknownLargeFields.map((entry) => `${entry.key}=${formatJsonSize(entry.byteSize)}`).join(' ')
      : 'none';
    console.info(`[SaveSize:team.fields] ${teamName} ${teamFieldSummary} unknownLargeFields=${unknownSummary}`);

    const players = Array.isArray(team.players) ? team.players : [];
    const farm = Array.isArray(team.farm) ? team.farm : [];
    const rosterPlayers = [...players, ...farm].filter((player) => player && typeof player === 'object');
    const playersSize = getJsonByteSize(players);
    const farmSize = getJsonByteSize(farm);
    const totalPlayerCount = rosterPlayers.length;
    const averagePlayerByteSize = totalPlayerCount > 0
      ? rosterPlayers.reduce((sum, player) => sum + Math.max(getJsonByteSize(player), 0), 0) / totalPlayerCount
      : 0;
    console.info(`[SaveSize:team.players] ${teamName} playersTotal=${formatJsonSize(playersSize)} farmTotal=${formatJsonSize(farmSize)} averagePlayer=${formatJsonSize(averagePlayerByteSize)}`);

    const topPlayers = rosterPlayers
      .map((player) => ({ player, byteSize: getJsonByteSize(player) }))
      .filter((entry) => entry.byteSize >= 0)
      .sort((a, b) => b.byteSize - a.byteSize)
      .slice(0, 10);

    topPlayers.forEach(({ player, byteSize }, index) => {
      const playerName = player.name ?? `unknown-${index + 1}`;
      const playerFieldSizes = collectObjectFieldSizes(player, [
        'stats', 'injuryHistory', 'batting', 'pitching', 'gameLogs', 'battedBallLogs',
        'physicsLogs', 'seasonStats', 'careerStats', 'careerLog', 'careerLogSummary',
      ]);
      const knownPlayerFieldKeys = new Set(['stats', 'injuryHistory', 'batting', 'pitching', 'gameLogs', 'battedBallLogs', 'physicsLogs', 'seasonStats', 'careerStats', 'careerLog', 'careerLogSummary']);
      const playerUnknownLarge = Object.keys(player)
        .filter((key) => !knownPlayerFieldKeys.has(key))
        .map((key) => ({ key, byteSize: getJsonByteSize(player[key]) }))
        .filter((entry) => entry.byteSize >= 10 * 1024)
        .sort((a, b) => b.byteSize - a.byteSize)
        .slice(0, 5);
      const safePlayerSize = byteSize > 0 ? byteSize : 1;
      const playerFieldSummary = playerFieldSizes
        .sort((a, b) => b.byteSize - a.byteSize)
        .map((entry) => `${entry.key}=${formatJsonSize(entry.byteSize)}(${((entry.byteSize / safePlayerSize) * 100).toFixed(1)}%)`)
        .join(' ');
      const playerUnknownSummary = playerUnknownLarge.length > 0
        ? playerUnknownLarge.map((entry) => `${entry.key}=${formatJsonSize(entry.byteSize)}`).join(' ')
        : 'none';
      const careerLogCount = Array.isArray(player.careerLog) ? player.careerLog.length : 0;
      const careerLogSummarySize = getJsonByteSize(player.careerLogSummary);
      const trimmedEntries = sanitizeNumber(player?.careerLogSummary?.trimmedEntries, 0);
      console.info(`[SaveSize:player.top] ${teamName} rank=${index + 1} name=${playerName} total=${formatJsonSize(byteSize)} careerLogCount=${careerLogCount} careerLogSummarySize=${formatJsonSize(careerLogSummarySize)} trimmedEntries=${trimmedEntries} ${playerFieldSummary} unknownLargeFields=${playerUnknownSummary}`);
      const topObjectFields = summarizeTopObjectFields(player, 3)
        .map((entry) => `${entry.key}=${formatJsonSize(entry.byteSize)}`)
        .join(' ');
      console.info(`[SaveSize:player.top.fields] ${teamName} name=${playerName} topFields=${topObjectFields}`);
    });
  });
}

function logTopLevelSaveSize(state) {
  if (!isSaveSizeDebugEnabled() || !state || typeof state !== 'object' || Array.isArray(state)) return;
  const measuredEntries = [];
  Object.keys(state).forEach((topLevelKey) => {
    const keyByteSize = getJsonByteSize(state[topLevelKey]);
    if (keyByteSize < 0) {
      console.warn(`[SaveSize] ${topLevelKey}: 計測失敗`);
      return;
    }
    measuredEntries.push({ key: topLevelKey, byteSize: keyByteSize });
  });
  measuredEntries
    .sort((a, b) => b.byteSize - a.byteSize)
    .forEach(({ key, byteSize }) => {
      console.info(`[SaveSize] ${key}: ${formatJsonSize(byteSize)}`);
    });
}

// ── 公開 API ────────────────────────────────────

function compress(state) {
  const stringifyStart = isDevEnv ? performance.now() : 0;
  const json = JSON.stringify(state);
  logPerf('saveGame.stringify', stringifyStart);
  const compressStart = isDevEnv ? performance.now() : 0;
  const compressed = LZString.compressToUTF16(json);
  logPerf('saveGame.compressToUTF16', compressStart);
  return { compressed, jsonLength: json.length, compressedLength: compressed?.length ?? 0 };
}

function decompress(raw) {
  // 既存の非圧縮セーブとの後方互換: 展開失敗時は生 JSON として扱う
  try {
    const decompressed = LZString.decompressFromUTF16(raw);
    if (decompressed) {
      const parseStart = isDevEnv ? performance.now() : 0;
      const parsed = JSON.parse(decompressed);
      logPerf('loadGame.parse', parseStart);
      return parsed;
    }
  } catch { /* fall through */ }
  const parseStart = isDevEnv ? performance.now() : 0;
  const parsed = JSON.parse(raw);
  logPerf('loadGame.parse', parseStart);
  return parsed;
}

function openSaveDb() {
  return openBaseballManagerDb();
}

async function idbWrite(storeName, key, value) {
  const db = await openSaveDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).put(value, key);
    tx.oncomplete = () => { db.close(); resolve(true); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('IndexedDB write failed')); };
  });
}

async function idbRead(storeName, key) {
  const db = await openSaveDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => { db.close(); resolve(req.result); };
    req.onerror = () => { db.close(); reject(req.error || new Error('IndexedDB read failed')); };
  });
}

export function resolveIndexedDbChunkScopes(dirtyScopes) {
  if (!Array.isArray(dirtyScopes)) return [...INDEXED_DB_CHUNK_SCOPES];
  const requested = new Set(dirtyScopes.filter((scope) => typeof scope === 'string' && scope));
  return INDEXED_DB_CHUNK_SCOPES.filter((scope) => requested.has(scope));
}

function normalizeRecentCareerLog(player) {
  const source = Array.isArray(player?.recentCareerLog)
    ? player.recentCareerLog
    : (Array.isArray(player?.careerLog) ? player.careerLog : []);
  return getRecentCareerLog(source, MAX_RECENT_CAREER_LOG_YEARS);
}


function normalizePlayerId(playerId) {
  return typeof playerId === 'string' ? playerId.trim() : '';
}

async function upsertCareerLogEntriesBatch(entriesByPlayer) {
  const db = await openSaveDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORES.careerLogs, 'readwrite');
    const store = tx.objectStore(IDB_STORES.careerLogs);
    const queue = entriesByPlayer instanceof Map ? Array.from(entriesByPlayer.entries()) : [];

    const readCurrent = (playerId) => new Promise((res, rej) => {
      const req = store.get(playerId);
      req.onsuccess = () => res(Array.isArray(req.result) ? req.result : []);
      req.onerror = () => rej(req.error || new Error('IndexedDB read failed'));
    });

    const writeNext = (playerId, value) => new Promise((res, rej) => {
      const req = store.put(value, playerId);
      req.onsuccess = () => res(true);
      req.onerror = () => rej(req.error || new Error('IndexedDB write failed'));
    });

    (async () => {
      for (const [playerIdRaw, rows] of queue) {
        const playerId = normalizePlayerId(playerIdRaw);
        if (!playerId || !Array.isArray(rows) || rows.length === 0) continue;
        const existing = await readCurrent(playerId);
        const byEntryKey = new Map();
        for (const row of existing) {
          const year = sanitizeYear(row?.year);
          if (year > 0) byEntryKey.set(getCareerEntryKey(row), row);
        }
        for (const row of rows) {
          const year = sanitizeYear(row?.year);
          if (year <= 0) continue;
          byEntryKey.set(getCareerEntryKey(row), row);
        }
        const merged = Array.from(byEntryKey.values()).sort((a, b) => sanitizeYear(a?.year) - sanitizeYear(b?.year));
        await writeNext(playerId, merged);
      }
    })().catch((error) => reject(error));

    tx.oncomplete = () => { db.close(); resolve({ ok: true }); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('IndexedDB batch upsert failed')); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error('IndexedDB batch upsert aborted')); };
  });
}

async function replaceCareerLogEntriesBatch(entriesByPlayer) {
  const db = await openSaveDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORES.careerLogs, 'readwrite');
    const store = tx.objectStore(IDB_STORES.careerLogs);
    for (const [playerIdRaw, rows] of entriesByPlayer instanceof Map ? entriesByPlayer.entries() : []) {
      const playerId = normalizePlayerId(playerIdRaw);
      if (!playerId || !Array.isArray(rows)) continue;
      store.put(
        rows
          .filter((row) => sanitizeYear(row?.year) > 0)
          .sort((a, b) => sanitizeYear(a?.year) - sanitizeYear(b?.year)),
        playerId,
      );
    }
    tx.oncomplete = () => { db.close(); resolve({ ok: true }); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('IndexedDB career log initialization failed')); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error('IndexedDB career log initialization aborted')); };
  });
}

async function saveGameImpl(state, options = {}) {
  // ⚠️ 入力値検証: 想定外の形式を保存しない（破損セーブ防止）
  if (!state || typeof state !== 'object' || !Array.isArray(state.teams)) {
    console.error('Save failed: invalid state payload');
    return { ok: false, quota: false, reason: 'invalid_state' };
  }
  const saveGameStart = isDevEnv ? performance.now() : 0;
  const skipCompression = options?.skipCompression === true;
  const skipBackupRotation = options?.skipBackupRotation === true;

  const perfBreakdown = {};
  let safeState;
  try {
    safeState = sanitizeSaveState(state);
    safeState.saveId = ensureSaveId(safeState.saveId);
    validateFarmSaveState(safeState);
  } catch (e) {
    console.error('Save failed: sanitize state error', e);
    return { ok: false, quota: false, reason: 'sanitize_state_failed' };
  }
  try {
    const indexedDbStart = isDevEnv ? performance.now() : 0;
    let previous = null;
    const currentRaw = localStorage.getItem(SAVE_KEY);
    const known = validatedRoots.get(localStorage);
    if (known?.saveId === safeState.saveId) previous = known;
    else try { if (currentRaw) previous = decompress(currentRaw); } catch { /* recovery */ }
    if(previous?.saveId===safeState.saveId && Number(previous.year)>Number(safeState.year)) {
      return {ok:false,quota:false,reason:'stale_save'};
    }
    if(previous?.saveId===safeState.saveId && previous.farmCompetitionVersion===1 && safeState.farmCompetitionVersion!==1) {
      return {ok:false,quota:false,reason:'farm_payload_missing'};
    }
    let generationDirtyScopes=options?.dirtyScopes;
    if(safeState.farmCompetition && previous?.farmCompetition?.archiveSignature!==safeState.farmCompetition.archiveSignature
      && Array.isArray(generationDirtyScopes)) {
      generationDirtyScopes=[...new Set([...generationDirtyScopes,'seasonHistory','matchHistory'])];
    }
    const careerData = await prepareCareerData(safeState, previous, options, legacyCareerSeeds.get(previous),state);
    let prepared;
    try { prepared = await prepareGeneration(safeState, previous, generationDirtyScopes, careerData); }
    catch (error) {
      if (error?.name !== 'QuotaExceededError') throw error;
      // Reclaim only rows proven unreferenced, then retry once. Never remove a backup root.
      await cleanupSaveChunks();
      prepared = await prepareGeneration(safeState, previous, generationDirtyScopes, careerData);
    }
    safeState.saveManifest = prepared.manifest;
    perfBreakdown.indexedDbMs = safeElapsedMs(indexedDbStart);
    perfBreakdown.indexedDbWriteCount = prepared.writeCount;
  } catch (e) {
    console.error('Save failed: IndexedDB write error', e);
    return { ok: false, quota: e?.name === 'QuotaExceededError', reason: 'indexeddb_write_failed' };
  }
  for (const key of MATCH_HISTORY_FIELDS) delete safeState[key];
  safeState.matchHistoryStored = true;
  safeState.seasonHistory = null;
  safeState.news = [];
  safeState.mailbox = [];
  safeState.teams = safeState.teams.map((team) => ({
    ...team,
    players: Array.isArray(team.players) ? team.players.map((p) => {
      const recentCareerLog = normalizeRecentCareerLog(p);
      const nextSummary = normalizeCareerLogSummary(p.careerLogSummary ?? buildCareerLogSummary(recentCareerLog));
      return { ...p, careerLog: [], recentCareerLog, careerLogSummary: nextSummary, trimmedCareerLogSummary: nextSummary };
    }) : [],
    farm: Array.isArray(team.farm) ? team.farm.map((p) => {
      const recentCareerLog = normalizeRecentCareerLog(p);
      const nextSummary = normalizeCareerLogSummary(p.careerLogSummary ?? buildCareerLogSummary(recentCareerLog));
      return { ...p, careerLog: [], recentCareerLog, careerLogSummary: nextSummary, trimmedCareerLogSummary: nextSummary };
    }) : [],
  }));
  safeState.saveDataVersion = SAVE_DATA_VERSION;

  const serializeStart = isDevEnv ? performance.now() : 0;
  logTopLevelSaveSize(safeState);
  logTeamsBreakdownSize(safeState);
  const json = JSON.stringify(safeState);
  logPerf('saveGame.stringify', serializeStart);
  let compressed = json;
  let compressedLength = json.length;
  if (!skipCompression) {
    const compressStart = isDevEnv ? performance.now() : 0;
    compressed = LZString.compressToUTF16(json);
    compressedLength = compressed?.length ?? 0;
    logPerf('saveGame.compressToUTF16', compressStart);
  }
  const jsonLength = json.length;
  const writeMeta = () => {
    const metaStart = isDevEnv ? performance.now() : 0;
    const myTeam = safeState.teams?.find(t => t.id === safeState.myId);
    localStorage.setItem(META_KEY, JSON.stringify({
      teamName:  myTeam?.name  ?? '不明',
      teamEmoji: myTeam?.emoji ?? '⚾',
      year:      safeState.year,
      gameDay:   safeState.gameDay,
      wins:      myTeam?.wins  ?? 0,
      losses:    myTeam?.losses ?? 0,
      savedAt:   new Date().toLocaleString('ja-JP'),
    }));
    perfBreakdown.writeMetaMs = safeElapsedMs(metaStart);
  };
  try {
    // Stage rotation without modifying roots. Failed primary writes leave both backups untouched.
    let rotationRaw = null;
    if (!skipBackupRotation && shouldRotateBackupNow()) {
      const raw = localStorage.getItem(SAVE_KEY);
      try {
        if (raw) {
          const previous = validatedRawRoots.get(localStorage) === raw ? validatedRoots.get(localStorage) : decompress(raw);
          if (Array.isArray(previous.teams) && hasSelectedTeam(previous.teams, previous.myId) && previous.year) {
            const hydratedPrevious = previous.saveDataVersion >= LEGACY_GENERATION_VERSION
              ? { ...previous, ...await readGeneration(previous) } : previous;
            validateFarmSaveState(hydratedPrevious);
            rotationRaw = raw;
          }
        }
      } catch { /* Never rotate a corrupt primary over a valid backup. */ }
    }
    const setItemStart = isDevEnv ? performance.now() : 0;
    localStorage.setItem(SAVE_KEY, compressed);
    perfBreakdown.writeMainSaveMs = safeElapsedMs(setItemStart);
    logPerf('saveGame.localStorage.setItem', setItemStart);
    observations.set(localStorage, compressed);
    validatedRoots.set(localStorage, safeState);
    validatedRawRoots.set(localStorage, compressed);
    const warnings = [];
    try { rememberChunkRoot(compressed, safeState); }
    catch (error) { warnings.push('root_cache_failed'); console.warn('Save committed; root cache failed:', error); }
    const rotateStart = isDevEnv ? performance.now() : 0;
    if (rotationRaw && !rotateBk(rotationRaw)) warnings.push('backup_failed');
    perfBreakdown.rotateBackupMs = safeElapsedMs(rotateStart);
    try { writeMeta(); } catch (error) { warnings.push('metadata_failed'); console.warn('Save committed; metadata failed:', error); }
    const cleanupStart = isDevEnv ? performance.now() : 0;
    try { await cleanupSaveChunks(); } catch (error) { warnings.push('cleanup_failed'); console.warn('Save committed; cleanup failed:', error); }
    perfBreakdown.cleanupMs = safeElapsedMs(cleanupStart);
    perfBreakdown.totalMs = safeElapsedMs(saveGameStart);
    perfBreakdown.jsonLength = jsonLength;
    perfBreakdown.compressedLength = compressedLength;
    appendSavePerfLog({ at: new Date().toISOString(), ...perfBreakdown });
    if (isDevEnv) console.table({ saveGame: perfBreakdown });
    logPerf('saveGame', saveGameStart);
    return { ok: true, generation: safeState.saveManifest.generation, warnings };
  } catch (e) {
    const quota = e instanceof DOMException && e.name === 'QuotaExceededError';
    if (quota) {
      console.error('Save failed: storage quota exceeded; committed generations retained');
      return { ok: false, quota: true, reason: 'quota_exceeded' };
    }
    console.error('Save failed:', e);
    return { ok: false, quota: false };
  }
}

// Observations are per storage surface so tests and isolated browsing contexts do not leak state.
const observations = new WeakMap();
const backupObservations = new WeakMap();
const validatedRoots = new WeakMap();
const validatedRawRoots = new WeakMap();
const deletionEpochs = new WeakMap();
const chunkRootCache = new WeakMap();
const legacyCareerSeeds = new WeakMap();
let localSaveTail = Promise.resolve();
let lastLoadResult = { status: 'none' };
function observePrimary() {
  observations.set(localStorage, localStorage.getItem(SAVE_KEY));
  backupObservations.set(localStorage, [localStorage.getItem(BACKUP_KEY_1), localStorage.getItem(BACKUP_KEY_2)]);
}
function rememberChunkRoot(raw, root) {
  let cache = chunkRootCache.get(localStorage);
  if (!cache) { cache = new Map(); chunkRootCache.set(localStorage, cache); }
  // Own only the metadata: callers may subsequently mutate loaded game state.
  const compact = structuredClone({ saveDataVersion: root.saveDataVersion,
    saveId: root.saveId, saveManifest: root.saveManifest });
  cache.set(raw, compact);
  if (cache.size > 4) cache.delete(cache.keys().next().value);
  return compact;
}
async function cleanupSaveChunks() {
  const raws = [SAVE_KEY, BACKUP_KEY_1, BACKUP_KEY_2].map(key => localStorage.getItem(key)).filter(raw => raw !== null);
  const cache = chunkRootCache.get(localStorage);
  // Prune even when a corrupt root later makes cleanup fail conservatively.
  if (cache) for (const raw of cache.keys()) if (!raws.includes(raw)) cache.delete(raw);
  const roots = raws.map(raw => {
    if (cache?.has(raw)) return cache.get(raw);
    const root = decompress(raw);
    // A cache miss must still protect the decoded persistent root if caching fails.
    try { return rememberChunkRoot(raw, root); } catch { return root; }
  });
  return collectUnusedChunks(roots);
}
export function saveGame(state, options = {}) {
  try { return saveOwnedSnapshot(structuredClone(state), structuredClone(options)); }
  catch { return Promise.resolve({ ok: false, quota: false, reason: 'snapshot_failed' }); }
}
function saveOwnedSnapshot(snapshot, safeOptions, deletionEpoch = deletionEpochs.get(localStorage) ?? 0) {
  try {
    if (!observations.has(localStorage)) observePrimary();
  } catch { return Promise.resolve({ ok: false, quota: false, reason: 'snapshot_failed' }); }
  const run = async () => {
    const locked = async () => {
      try {
        const currentPrimary = localStorage.getItem(SAVE_KEY);
        const backupChanged = currentPrimary === null && (backupObservations.get(localStorage) ?? []).some((raw, index) => raw !== localStorage.getItem([BACKUP_KEY_1, BACKUP_KEY_2][index]));
        if (deletionEpoch !== (deletionEpochs.get(localStorage) ?? 0) || observations.get(localStorage) !== currentPrimary || backupChanged) {
          return { ok: false, quota: false, reason: 'save_conflict' };
        }
        return await saveGameImpl(snapshot, safeOptions);
      } catch (error) {
        return { ok: false, quota: error?.name === 'QuotaExceededError', reason: 'save_failed' };
      }
    };
    if (globalThis.navigator?.locks?.request) return navigator.locks.request('baseball-manager-save', locked);
    // A browser without origin-wide locking must fail closed instead of silently racing tabs.
    if (typeof window !== 'undefined') return { ok: false, quota: false, reason: 'save_lock_unavailable' };
    return locked();
  };
  const result = localSaveTail.then(run, run);
  localSaveTail = result.catch(() => {});
  return result;
}
const sharedSaveQueue = createSaveRequestQueue(({ state, options, deletionEpoch }) => saveOwnedSnapshot(state, options, deletionEpoch));

export function enqueueSaveGame(state, options = {}) {
  try { return sharedSaveQueue.enqueue({ state: structuredClone(state), options: structuredClone(options), deletionEpoch: deletionEpochs.get(localStorage) ?? 0 }); }
  catch { return Promise.resolve({ ok: false, quota: false, reason: 'snapshot_failed' }); }
}

export function getLastLoadResult() { return { ...lastLoadResult }; }

export function getSaveQueueSnapshot() {
  return sharedSaveQueue.getSnapshot();
}

export function getSavePerfLogs() {
  try {
    const raw = localStorage.getItem(PERF_LOG_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function clearSavePerfLogs() {
  try {
    localStorage.removeItem(PERF_LOG_KEY);
    return { ok: true };
  } catch (e) {
    console.error('Clear save perf logs failed:', e);
    return { ok: false };
  }
}

export function getSavePerfSummary() {
  const logs = getSavePerfLogs();
  if (!Array.isArray(logs) || logs.length === 0) {
    return {
      count: 0,
      average: null,
      slowest: null,
    };
  }
  const safeNumber = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
  const sum = logs.reduce((acc, row) => ({
    totalMs: acc.totalMs + safeNumber(row.totalMs),
    rotateBackupMs: acc.rotateBackupMs + safeNumber(row.rotateBackupMs),
    writeMainSaveMs: acc.writeMainSaveMs + safeNumber(row.writeMainSaveMs),
    writeMetaMs: acc.writeMetaMs + safeNumber(row.writeMetaMs),
    jsonLength: acc.jsonLength + safeNumber(row.jsonLength),
    compressedLength: acc.compressedLength + safeNumber(row.compressedLength),
  }), {
    totalMs: 0,
    rotateBackupMs: 0,
    writeMainSaveMs: 0,
    writeMetaMs: 0,
    jsonLength: 0,
    compressedLength: 0,
  });
  const average = {
    totalMs: sum.totalMs / logs.length,
    rotateBackupMs: sum.rotateBackupMs / logs.length,
    writeMainSaveMs: sum.writeMainSaveMs / logs.length,
    writeMetaMs: sum.writeMetaMs / logs.length,
    jsonLength: sum.jsonLength / logs.length,
    compressedLength: sum.compressedLength / logs.length,
  };
  const slowest = logs.reduce((prev, current) => (safeNumber(current.totalMs) > safeNumber(prev?.totalMs) ? current : prev), logs[0]);
  return { count: logs.length, average, slowest };
}

export async function loadGame() {
  const loadGameStart = isDevEnv ? performance.now() : 0;
  lastLoadResult = { status: 'none' };
  let foundCandidate = false;
  let primaryAtLoad;
  let backupsAtLoad;
  try { primaryAtLoad = localStorage.getItem(SAVE_KEY); backupsAtLoad = [localStorage.getItem(BACKUP_KEY_1), localStorage.getItem(BACKUP_KEY_2)]; } catch { primaryAtLoad = null; backupsAtLoad = []; }
  const candidates = [
    { key: SAVE_KEY,     label: 'primary' },
    { key: BACKUP_KEY_1, label: 'backup-1' },
    { key: BACKUP_KEY_2, label: 'backup-2' },
  ];
  for (const { key, label } of candidates) {
    try {
      const getItemStart = isDevEnv ? performance.now() : 0;
      const raw = localStorage.getItem(key);
      logPerf('loadGame.localStorage.getItem', getItemStart);
      if (!raw) continue;
      foundCandidate = true;
      const state = decompress(raw);
      if (state?.saveDataVersion >= LEGACY_GENERATION_VERSION) {
        Object.assign(state, await readGeneration(state));
      } else if (state?.saveDataVersion >= INDEXED_DB_LARGE_DATA_VERSION) {
        try {
          state.seasonHistory = (await idbRead(IDB_STORES.chunks, 'seasonHistory')) ?? state.seasonHistory;
          state.news = (await idbRead(IDB_STORES.chunks, 'news')) ?? state.news;
          state.mailbox = (await idbRead(IDB_STORES.chunks, 'mailbox')) ?? state.mailbox;
          if (state.matchHistoryStored) {
            const history = await idbRead(IDB_STORES.chunks, 'matchHistory');
            if (!history) throw new Error('missing_match_history');
            Object.assign(state, matchHistorySnapshot(history));
          }
          state.saveRevision = sanitizeNumber(state.saveRevision, 0);
        } catch (e) {
          if (state.matchHistoryStored) throw e;
          console.warn('IndexedDB load failed. Fallback to localStorage payload.', e);
        }
      }
      if(!(state?.saveDataVersion >= GENERATION_VERSION)) legacyCareerSeeds.set(state,captureInlineCareerLogs(state));
      for (const team of (state?.teams || [])) {
        for (const bucket of ['players', 'farm']) {
          for (const player of (team?.[bucket] || [])) {
            const legacyCareerLog = Array.isArray(player?.careerLog) ? player.careerLog : [];
            const recentCareerLog = Array.isArray(player?.recentCareerLog)
              ? getRecentCareerLog(player.recentCareerLog, MAX_RECENT_CAREER_LOG_YEARS)
              : getRecentCareerLog(legacyCareerLog, MAX_RECENT_CAREER_LOG_YEARS);
            player.recentCareerLog = recentCareerLog;
            player.careerLogSummary = normalizeCareerLogSummary(player.careerLogSummary ?? buildCareerLogSummary(legacyCareerLog));
            player.trimmedCareerLogSummary = normalizeCareerLogSummary(player.trimmedCareerLogSummary ?? player.careerLogSummary);
            player.careerLog = [];
          }
        }
      }
      const result = validateAndMigrateSave(state);
      if (result.ok) {
        if (key !== SAVE_KEY) console.warn(`Loaded from ${label}`);
        logPerf('loadGame', loadGameStart);
        observations.set(localStorage, primaryAtLoad);
        backupObservations.set(localStorage, backupsAtLoad);
        validatedRoots.set(localStorage, result.state);
        if(legacyCareerSeeds.has(state)) legacyCareerSeeds.set(result.state,legacyCareerSeeds.get(state));
        validatedRawRoots.set(localStorage, raw);
        try { rememberChunkRoot(raw, result.state); }
        catch (error) { console.warn('Load succeeded; root cache failed:', error); }
        lastLoadResult = { status: key === SAVE_KEY ? 'primary' : 'recovered', source: label, generation: state.saveManifest?.generation };
        return result.state;
      }
      console.warn(`Validation failed for ${label}`);
    } catch (e) {
      console.error(`Load from ${label} failed:`, e);
    }
  }
  lastLoadResult = { status: foundCandidate ? 'unrecoverable' : 'none' };
  return null;
}

export async function loadPlayerCareerLogById(playerId, saveId) {
  if (typeof playerId !== 'string' || playerId.trim() === '') return [];
  if (saveId) {
    let root=validatedRoots.get(localStorage);
    if(root?.saveId!==saveId) root=await loadGame();
    if(root?.saveId!==saveId) throw new Error('career_save_mismatch');
    if(root.saveDataVersion===GENERATION_VERSION) {
      const data=await readCareerGeneration(root);return new Map(data.players).get(playerId) || [];
    }
    const data=await prepareCareerData(root,root,{},legacyCareerSeeds.get(root));
    return new Map(data.players).get(playerId) || [];
  }
  try {
    const loaded = await idbRead(IDB_STORES.careerLogs, playerId);
    return Array.isArray(loaded) ? loaded : [];
  } catch (e) {
    console.warn('Career log load failed:', e);
    return [];
  }
}

export async function appendCareerEntryToIndexedDb(playerId, careerEntry) {
  const normalizedPlayerId = normalizePlayerId(playerId);
  if (!normalizedPlayerId || !careerEntry || typeof careerEntry !== 'object') return { ok: false };
  try {
    const entriesByPlayer = new Map([[normalizedPlayerId, [careerEntry]]]);
    await upsertCareerLogEntriesBatch(entriesByPlayer);
    return { ok: true };
  } catch (e) {
    console.warn('Career log append failed:', e);
    return { ok: false };
  }
}

export async function appendCareerEntriesToIndexedDb(entries) {
  if (!Array.isArray(entries) || entries.length === 0) return { ok: true, appendedPlayers: 0 };
  const entriesByPlayer = new Map();
  for (const item of entries) {
    const playerId = normalizePlayerId(item?.playerId);
    const careerEntry = item?.careerEntry;
    if (!playerId || !careerEntry || typeof careerEntry !== 'object') continue;
    const existing = entriesByPlayer.get(playerId) || [];
    entriesByPlayer.set(playerId, [...existing, careerEntry]);
  }
  if (entriesByPlayer.size === 0) return { ok: false, appendedPlayers: 0 };
  try {
    await upsertCareerLogEntriesBatch(entriesByPlayer);
    return { ok: true, appendedPlayers: entriesByPlayer.size };
  } catch (e) {
    console.warn('Career log batch append failed:', e);
    return { ok: false, appendedPlayers: 0 };
  }
}

export async function initializeCareerLogsInIndexedDb(entries) {
  if (!Array.isArray(entries) || entries.length === 0) return { ok: true, initializedPlayers: 0 };
  const entriesByPlayer = new Map();
  for (const item of entries) {
    const playerId = normalizePlayerId(item?.playerId);
    const careerEntries = Array.isArray(item?.careerEntries) ? item.careerEntries : [];
    if (!playerId || careerEntries.length === 0) continue;
    entriesByPlayer.set(playerId, careerEntries);
  }
  if (entriesByPlayer.size === 0) return { ok: false, initializedPlayers: 0 };
  try {
    await replaceCareerLogEntriesBatch(entriesByPlayer);
    return { ok: true, initializedPlayers: entriesByPlayer.size };
  } catch (e) {
    console.error('Career log initialization failed:', e);
    return { ok: false, initializedPlayers: 0, reason: 'indexeddb_write_failed' };
  }
}


export function getAutoSaveIntervalMs() {
  return AUTO_SAVE_INTERVAL_MS;
}

export function hasSave() {
  try {
    return [SAVE_KEY, BACKUP_KEY_1, BACKUP_KEY_2].some(key => !!localStorage.getItem(key));
  } catch (error) {
    // ⚠️ セキュリティ: ブラウザ設定によりStorage API【＝ブラウザ内保存機能】が拒否される場合があるため、必ず例外を握りつぶして初期表示を継続する
    console.warn('hasSave failed. Falling back to no-save mode.', error);
    return false;
  }
}

export function getSaveMeta() {
  try {
    const raw = localStorage.getItem(META_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function deleteSaveImpl() {
  chunkRootCache.delete(localStorage);
  observations.set(localStorage, null);
  backupObservations.set(localStorage, [null, null]);
  validatedRoots.delete(localStorage);
  validatedRawRoots.delete(localStorage);
  let saveId = null;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) saveId = decompress(raw)?.saveId ?? null;
  } catch {
    saveId = null;
  }
  localStorage.removeItem(SAVE_KEY);
  localStorage.removeItem(META_KEY);
  localStorage.removeItem(BACKUP_KEY_1);
  localStorage.removeItem(BACKUP_KEY_2);
  if (saveId) {
    import('./battedBallArchive')
      .then((mod) => mod.deleteBattedBallArchiveBySaveId(saveId))
      .catch((error) => console.warn('打球アーカイブ削除に失敗しました', error));
  }
  return { ok: true };
}

export function deleteSave() {
  // Invalidate requests already waiting in the coalescing queue before taking the same lock.
  deletionEpochs.set(localStorage, (deletionEpochs.get(localStorage) ?? 0) + 1);
  const run = async () => {
    try {
      if (globalThis.navigator?.locks?.request) return await navigator.locks.request('baseball-manager-save', deleteSaveImpl);
      if (typeof window !== 'undefined') return { ok: false, reason: 'save_lock_unavailable' };
      return deleteSaveImpl();
    } catch { return { ok: false, reason: 'delete_failed' }; }
  };
  const result = localSaveTail.then(run, run);
  localSaveTail = result.catch(() => {});
  return result;
}
