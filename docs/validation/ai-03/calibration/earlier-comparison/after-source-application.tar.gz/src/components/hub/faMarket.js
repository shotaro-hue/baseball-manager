import { FOREIGN_DEADLINE_DAY, MIN_ACTIVE_CATCHERS, MIN_TOTAL_BY_POS } from '../../constants';
import { fmtIP } from '../../utils';
import { saberBatter } from '../../engine/sabermetrics';
import { marketPlacement, marketRosterError } from '../../engine/marketRoster';
export { marketPlacement } from '../../engine/marketRoster';
import { prepareOffseasonFreeAgent } from '../../engine/offseasonMarket';
import { isIkuseiPlayer } from '../../engine/rosterAutomation';

export function marketMetrics(player) {
  const s = (player.isFA && player.marketLastStats) || player.stats || {};
  const measured = keys => keys.every(key => Number.isFinite(s[key]));
  const value = n => Number.isFinite(n) ? n : '未記録';
  if (player.isPitcher) return [['投球回', Number.isFinite(s.IP) ? fmtIP(s.IP) : '未記録'], ['防御率', measured(['IP', 'ER']) && s.IP > 0 ? (s.ER / s.IP * 9).toFixed(2) : '—'], ['勝利', value(s.W)], ['奪三振', value(s.Kp)], ['セーブ', value(s.SV)], ['ホールド', value(s.HLD)]];
  const denominator = s.AB + s.BB + s.HBP + s.SF;
  const ops = measured(['AB', 'H', 'BB', 'HBP', 'SF', 'D', 'T', 'HR']) && s.AB > 0 && denominator > 0 ? saberBatter(s).OPS.toFixed(3) : '—';
  return [['打席', value(s.PA)], ['打率', measured(['AB', 'H']) && s.AB > 0 ? (s.H / s.AB).toFixed(3) : '—'], ['本塁打', value(s.HR)], ['打点', value(s.RBI)], ['OPS', ops]];
}

// Structural hints from saved roster counts, without inventing ability or performance.
export function marketNeeds(team) {
  const players = team?.players || [];
  const all = [...players, ...(team?.farm || [])];
  const hints = [];
  for (const [label, count, target] of [
    ['先発', players.filter(p => p.isPitcher && (p.subtype || p.pos) === '先発').length, 4],
    ['中継ぎ', players.filter(p => p.isPitcher && (p.subtype || p.pos) === '中継ぎ').length, 3],
    ['抑え', players.filter(p => p.isPitcher && (p.subtype || p.pos) === '抑え').length, 1],
    ['捕手（登録）', players.filter(p => !p.isPitcher && p.pos === '捕手').length, MIN_ACTIVE_CATCHERS],
    ['捕手（登録＋ファーム）', all.filter(p => !p.isPitcher && p.pos === '捕手' && !isIkuseiPlayer(p)).length, MIN_TOTAL_BY_POS['捕手']],
  ]) if (count < target) hints.push(`${label} ${count}/${target}人`);
  return hints;
}

export function validateMarketContract({ team, pool, player, salary, years, gameDay, teams = [team], draftContext = {} }) {
  if (!pool.some(p => p.id === player.id)) return 'この選手は現在の市場にいません';
  const rosterError = marketRosterError(team, player, teams, draftContext);
  if (rosterError) return rosterError;
  if (player.isForeign && (!Number.isFinite(gameDay) || gameDay > FOREIGN_DEADLINE_DAY)) return '外国人補強の期限を過ぎているか、日程が未記録です';
  if (!Number.isFinite(salary) || salary <= 0 || !Number.isInteger(years) || years < 1 || years > 3) return '契約金額または年数を確認してください';
  if (isIkuseiPlayer(player) && player.departureReason !== 'ikusei_expiry' && years > Math.max(1, 3 - (player.ikuseiYears || 0))) return '育成3年満了までに収まる契約年数を選んでください';
  if (!Number.isFinite(team?.budget)) return '予算が未記録のため契約できません';
  if (team.budget < salary * years) return '予算が不足しています';
  return null;
}

export function addMarketSigning(team, player, salary, years, year, marketMode = 'season', draftContext = {}) {
  if (marketRosterError(team, player, draftContext.teams ?? [team], draftContext)) return team;
  const placement = marketPlacement(team, player);
  const prepared = marketMode === 'offseason' ? prepareOffseasonFreeAgent(player, year, team.id) : player;
  const signed = { ...prepared, isFA: false, salary, contractYears: years, contractYearsLeft: years, contractSignedYear: year,
    ...(isIkuseiPlayer(player) && player.departureReason === 'ikusei_expiry' ? { ikuseiYears: 0 } : {}) };
  return { ...team, budget: team.budget - salary * years,
    players: placement.farm ? team.players : [...team.players, signed],
    farm: placement.farm ? [...(team.farm || []), signed] : team.farm || [],
    history: [...(team.history || []), { ...signed, exitYear: year, exitReason: player.isForeign ? 'foreign_fa' : player.isWaiverReleased ? 'waiver_fa' : 'fa', tenure: 0 }],
  };
}
