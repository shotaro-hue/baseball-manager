import {prepareFarmProgress,finishFarmProgress} from '../engine/farmProgression';
import {selectFarmUsage} from '../engine/farmSelectors';
import { regularSeasonRequest } from '../engine/seasonProgress';
import { getMyMatchup } from '../engine/scheduleGen';
import { uid, rng, rngf, gameDayToDate } from '../utils';
import * as playerRules from '../engine/player';
import { calcRetireWill } from '../engine/player';
import { applyRegularSeasonTeamUpdate } from '../engine/regularGameUpdates';
import { quickSimGame } from '../engine/simulation';
import { computeBoxScore } from '../engine/postGame';
import {
  createBattedBallArchiveChunker,
  createBattedBallBatchRecords,
} from '../engine/battedBallProfile';
import { generateCpuOffer, generateCpuCpuTrade, classifyTeam, evaluateFrontOfficePlan } from '../engine/trade';
import { executeCpuTrade } from '../engine/cpuTradeExecution';
import { selectAllStars, runAllStarGame } from '../engine/allstar';
import { getCpuMatchups } from '../engine/scheduleGen';
import {
  applyEmergencyRosterMaintenance,
  applyManagementPolicy,
  ROSTER_AUTOMATION_MODES,
  prepareTeamForGame,
} from '../engine/rosterAutomation';
import {
  SEASON_GAMES,
  NEWS_TEMPLATES_WIN,
  NEWS_TEMPLATES_LOSE,
  INTERVIEW_QUESTIONS_WIN,
  INTERVIEW_QUESTIONS_LOSE,
  INTERVIEW_OPTIONS_WIN,
  INTERVIEW_OPTIONS_LOSE,
  TRADE_DEADLINE_MONTH,
  TRADE_DEADLINE_PROB_EARLY,
  TRADE_DEADLINE_PROB_PEAK,
  TRADE_DEADLINE_CPU_CPU_PROB,
} from '../constants';

function cloneValue(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function ensureNotCancelled(isCancelled) {
  if (typeof isCancelled === 'function' && isCancelled()) {
    throw new Error('single-day simulation cancelled');
  }
}

function emitProgress(onProgress, phase, force = false) {
  if (typeof onProgress !== 'function') return;
  onProgress({
    current: force ? 1 : 0,
    total: 1,
    avgMsPerGame: 0,
    etaSec: force ? 0 : 1,
    phase,
  });
}


function applyDhToTeam(team, useDh) {
  return prepareTeamForGame(team, useDh);
}

function buildGameResultsMapPatch(gameNo, result, oppTeam, isHome = true) {
  return {
    [gameNo]: {
      won: result.won,
      drew: result.score.my === result.score.opp,
      isHome,
      oppName: oppTeam?.name || '',
      myScore: result.score.my,
      oppScore: result.score.opp,
      log: result.log || [],
      inningSummary: result.inningSummary || [],
      oppTeam,
    },
  };
}

function buildAllTeamResultEntry(homeId, awayId, cr, bs, homeName, awayName, dayNo) {
  const homeWon = cr.won;
  const drew = cr.score.my === cr.score.opp;
  return {
    [homeId]: {
      [dayNo]: {
        won: homeWon,
        drew,
        myScore: cr.score.my,
        oppScore: cr.score.opp,
        oppName: awayName,
        oppId: awayId,
        homeId,
        awayId,
        inningScores: bs?.inningScores,
        myBatting: bs?.homeBatting,
        oppBatting: bs?.awayBatting,
        myPitching: bs?.homePitching,
        oppPitching: bs?.awayPitching,
      },
    },
    [awayId]: {
      [dayNo]: {
        won: !homeWon && !drew,
        drew,
        myScore: cr.score.opp,
        oppScore: cr.score.my,
        oppName: homeName,
        oppId: homeId,
        homeId,
        awayId,
        inningScores: bs?.inningScores,
        myBatting: bs?.awayBatting,
        oppBatting: bs?.homeBatting,
        myPitching: bs?.awayPitching,
        oppPitching: bs?.homePitching,
      },
    },
  };
}

function mergeAllTeamResultPatches(target, patch) {
  Object.entries(patch || {}).forEach(([teamId, dayMap]) => {
    target[teamId] = { ...(target[teamId] || {}), ...(dayMap || {}) };
  });
}

function buildAllStarNewsItems(asResult, dayLabel, year) {
  if (!asResult) return [];
  return [
    {
      type: 'allstar',
      headline: `オールスター第1戦 セ${asResult.game1.score.ce} - パ${asResult.game1.score.pa}`,
      source: 'NPB公式',
      dateLabel: `${year}年 ${dayLabel}日目`,
      body: `会場: ${asResult.venue}\nセ・リーグ ${asResult.game1.score.ce} - ${asResult.game1.score.pa} パ・リーグ\nMVP: ${asResult.game1.mvp?.name || '選出なし'}`,
    },
    {
      type: 'allstar',
      headline: `オールスター第2戦 セ${asResult.game2.score.ce} - パ${asResult.game2.score.pa}`,
      source: 'NPB公式',
      dateLabel: `${year}年 ${dayLabel + 1}日目`,
      body: `セ・リーグ ${asResult.game2.score.ce} - ${asResult.game2.score.pa} パ・リーグ\nMVP: ${asResult.game2.mvp?.name || '選出なし'}`,
    },
  ];
}

function applyAllStarSelections(baseTeams, rosters) {
  const pickedIds = new Set([...(rosters?.ce || []), ...(rosters?.pa || [])].map((player) => player.id));
  return baseTeams.map((team) => ({
    ...team,
    players: (team.players || []).map((player) => (
      pickedIds.has(player.id)
        ? { ...player, allStarSelections: (player.allStarSelections || 0) + 1 }
        : player
    )),
  }));
}

function buildTransferEntry(tradeNews, year, gameDay) {
  if (!tradeNews) return null;
  return {
    id: uid(),
    timestamp: Date.now(),
    year,
    day: gameDay,
    type: 'trade',
    headline: `CPUトレード ${tradeNews.sellerName} -> ${tradeNews.buyerName}`,
    fromTeam: tradeNews.sellerName,
    toTeam: tradeNews.buyerName,
    playersIn: [tradeNews.buyerGetsName],
    playersOut: [tradeNews.sellerGetsName],
    detail: tradeNews.body,
  };
}

function tryGenerateCpuOfferSingleDay(teams, snapshot) {
  const currentDate = gameDayToDate(snapshot.gameDay, snapshot.schedule);
  if (currentDate && currentDate.month > TRADE_DEADLINE_MONTH) return null;
  let prob = 0.15;
  if (currentDate && currentDate.month === TRADE_DEADLINE_MONTH) {
    prob = currentDate.day > 15 ? TRADE_DEADLINE_PROB_PEAK : TRADE_DEADLINE_PROB_EARLY;
  }
  if (rngf(0, 1) > prob) return null;
  const myTeam = teams.find((team) => team.id === snapshot.myId);
  if (!myTeam) return null;
  const others = teams.filter((team) => team.id !== snapshot.myId);
  others.forEach((team) => {
    team.frontOfficePlan = evaluateFrontOfficePlan(team, teams, snapshot.gameDay);
  });
  if (!others.length) return null;
  let cpuTeam;
  if (currentDate && currentDate.month === TRADE_DEADLINE_MONTH) {
    const buyers = others.filter((team) => classifyTeam(team, teams) === 'buyer');
    cpuTeam = buyers.length ? buyers[rng(0, buyers.length - 1)] : others[rng(0, others.length - 1)];
  } else {
    cpuTeam = others[rng(0, others.length - 1)];
  }
  const offer = generateCpuOffer(cpuTeam, myTeam);
  if (!offer) return null;
  return {
    id: uid(),
    type: 'trade',
    title: `${offer.from.name}からトレードオファー`,
    from: offer.from.name,
    dateLabel: `${snapshot.year}年 ${snapshot.gameDay}日目`,
    timestamp: Date.now(),
    read: false,
    resolved: false,
    body: `${offer.from.name}よりトレードの打診がありました。\n\n・獲得したい選手: ${offer.want.map((player) => player.name).join('、')}\n・放出候補: ${offer.offer.length > 0 ? offer.offer.map((player) => player.name).join('、') : 'なし'}${offer.cash > 0 ? `\n・金銭: +${(offer.cash / 10000).toLocaleString()}万円` : ''}\n\nメール画面から返答してください。`,
    offer,
  };
}

function tryCpuCpuDeadlineTradeSingleDay(teams, snapshot) {
  const currentDate = gameDayToDate(snapshot.gameDay, snapshot.schedule);
  if (!currentDate || currentDate.month !== TRADE_DEADLINE_MONTH) return null;
  if (rngf(0, 1) > TRADE_DEADLINE_CPU_CPU_PROB) return null;
  teams.forEach((team) => {
    team.frontOfficePlan = evaluateFrontOfficePlan(team, teams, snapshot.gameDay);
  });
  const result = generateCpuCpuTrade(teams.filter((team) => team.id !== snapshot.myId));
  if (!result) return null;
  const { buyerId, sellerId, buyerGets, sellerGets, buyerName, sellerName } = result;
  const buyer = teams.find((team) => team.id === buyerId);
  const seller = teams.find((team) => team.id === sellerId);
  if (!buyer || !seller) return null;
  if (!executeCpuTrade(teams, result, snapshot.gameDay)) return null;
  return {
    headline: `移籍情報 ${buyerGets.name}が${buyerName}へ`,
    body: `${sellerName}と${buyerName}の間でトレードが成立。${buyerName}は${buyerGets.name}を獲得し、${sellerGets.name}を放出しました。`,
    buyerName,
    sellerName,
    buyerGetsName: buyerGets.name,
    sellerGetsName: sellerGets.name,
  };
}

function updateTeamAfterGame(team, result, isMyPerspective, gameDay, year, isHomeTeam = isMyPerspective, maintainRoster = false) {
  const update = applyRegularSeasonTeamUpdate(team, result, { isFirstTeam: isMyPerspective, isHomeTeam, gameDay, year }, playerRules);
  if (maintainRoster) update.team = applyEmergencyRosterMaintenance(update.team);
  return update;
}

function maybeBuildRetireAnnouncement(team, year, gameDay) {
  if (!team || Math.random() >= 0.04) return null;
  const candidates = (team.players || []).filter((player) => player.age >= 35 && !player._retireNow && calcRetireWill(player) >= 40);
  if (candidates.length === 0) return null;
  const player = candidates[rng(0, candidates.length - 1)];
  return {
    modal: { player, type: 'announce' },
    news: {
      type: 'season',
      headline: `引退表明 ${player.name}`,
      source: 'スポーツ報知',
      dateLabel: `${year}年 ${gameDay}日目`,
      body: `${player.name}（${player.age}歳）が引退を表明するコメントを出しました。チームは試合後、本人の意思を確認していきます。`,
    },
  };
}

export function simulateSingleDay({
  snapshot,
  gameContext,
  isCancelled,
  onProgress,
  onArchiveChunk,
}) {
  const request = regularSeasonRequest(snapshot, 1);
  if (!request.count) throw new Error(request.reason);
  const matchup = getMyMatchup(snapshot.schedule, snapshot.gameDay, snapshot.myId);
  if (matchup.oppId !== gameContext?.selectedOpponentId || matchup.isHome !== gameContext?.isHome) throw new Error('対戦日程と要求が一致しません。');
  const safeSnapshot = cloneValue(snapshot || {});
  const farmUsage = selectFarmUsage(safeSnapshot.farmCompetition);
  const teams = (safeSnapshot.teams || []).map(team => team.id === safeSnapshot.myId ? team : applyManagementPolicy(team, {
    teams: safeSnapshot.teams, gameDay: safeSnapshot.gameDay, includeRosterChanges: true, automationMode: ROSTER_AUTOMATION_MODES.FULL,
    farmUsage,
  }));
  const myTeam = teams.find((team) => team.id === safeSnapshot.myId);
  const currentOpp = teams.find((team) => team.id === gameContext?.selectedOpponentId);
  if (!myTeam || !currentOpp) {
    throw new Error('single-day simulation requires both my team and opponent');
  }

  emitProgress(onProgress, '試合シム');
  ensureNotCancelled(isCancelled);
  const archiveChunker = createBattedBallArchiveChunker(onArchiveChunk);
  const archiveGame = (log, firstTeam, secondTeam) => {
    archiveChunker.add(createBattedBallBatchRecords(log, {
      saveId: safeSnapshot.saveId,
      year: safeSnapshot.year,
      gameDay: safeSnapshot.gameDay,
      gameId: `${safeSnapshot.gameDay}:${firstTeam?.id ?? 'team1'}:${secondTeam?.id ?? 'team2'}`,
      teams: [firstTeam, secondTeam],
      source: 'worker',
    }));
  };

  const useDh = !!gameContext?.useDh;
  const isHome = gameContext?.isHome !== false;
  const farmProgress = prepareFarmProgress(safeSnapshot,teams,safeSnapshot.gameDay);
  const userGameResult = quickSimGame(
    applyDhToTeam(myTeam, useDh),
    applyDhToTeam(currentOpp, useDh),
    { simulationMode: gameContext?.simulationMode || 'detailed', isMyHome: isHome },
  );
  archiveGame(userGameResult.log, myTeam, currentOpp);
  const won = userGameResult.score.my > userGameResult.score.opp;
  const drew = userGameResult.score.my === userGameResult.score.opp;

  const nextTeams = teams.map((team) => ({
    ...team,
    players: cloneValue(team.players || []),
    farm: cloneValue(team.farm || []),
  }));
  const myTeamIndex = nextTeams.findIndex((team) => team.id === safeSnapshot.myId);
  const oppTeamIndex = nextTeams.findIndex((team) => team.id === currentOpp.id);
  const myUpdate = updateTeamAfterGame(nextTeams[myTeamIndex], userGameResult, true, safeSnapshot.gameDay, safeSnapshot.year, isHome, true);
  const oppUpdate = updateTeamAfterGame(nextTeams[oppTeamIndex], userGameResult, false, safeSnapshot.gameDay, safeSnapshot.year, !isHome);
  nextTeams[myTeamIndex] = myUpdate.team;
  nextTeams[oppTeamIndex] = oppUpdate.team;

  emitProgress(onProgress, '他試合処理');
  ensureNotCancelled(isCancelled);

  const cpuMatchups = getCpuMatchups(safeSnapshot.schedule, safeSnapshot.gameDay, safeSnapshot.myId, currentOpp.id);
  const matchupList = cpuMatchups;

  const allTeamResultsPatch = {};
  const gameResultsMapPatch = buildGameResultsMapPatch(safeSnapshot.gameDay, userGameResult, currentOpp, isHome);
  const myBoxScore = computeBoxScore(
    userGameResult.log || [],
    userGameResult.inningSummary || [],
    isHome ? myTeam.players : currentOpp.players,
    isHome ? currentOpp.players : myTeam.players,
    isHome ? userGameResult.score.my : userGameResult.score.opp,
    isHome ? userGameResult.score.opp : userGameResult.score.my,
  );
  const homePerspectiveUserResult = isHome
    ? userGameResult
    : {
        ...userGameResult,
        won: userGameResult.score.opp > userGameResult.score.my,
        score: { my: userGameResult.score.opp, opp: userGameResult.score.my },
      };
  mergeAllTeamResultPatches(
    allTeamResultsPatch,
    buildAllTeamResultEntry(isHome ? safeSnapshot.myId : currentOpp.id, isHome ? currentOpp.id : safeSnapshot.myId, homePerspectiveUserResult, myBoxScore, isHome ? myTeam.name : currentOpp.name, isHome ? currentOpp.name : myTeam.name, safeSnapshot.gameDay),
  );

  for (const matchup of matchupList) {
    ensureNotCancelled(isCancelled);
    const homeIndex = nextTeams.findIndex((team) => team.id === matchup.homeId);
    const awayIndex = nextTeams.findIndex((team) => team.id === matchup.awayId);
    if (homeIndex === -1 || awayIndex === -1) continue;
    const homeTeam = nextTeams[homeIndex];
    const awayTeam = nextTeams[awayIndex];
    const cpuResult = quickSimGame(
      applyDhToTeam(homeTeam, !!homeTeam.dhEnabled),
      applyDhToTeam(awayTeam, !!homeTeam.dhEnabled),
      { simulationMode: gameContext?.simulationMode || 'detailed' },
    );
    archiveGame(cpuResult.log, homeTeam, awayTeam);
    nextTeams[homeIndex] = updateTeamAfterGame(homeTeam, cpuResult, true, safeSnapshot.gameDay, safeSnapshot.year).team;
    nextTeams[awayIndex] = updateTeamAfterGame(awayTeam, cpuResult, false, safeSnapshot.gameDay, safeSnapshot.year).team;
    const cpuBoxScore = computeBoxScore(
      cpuResult.log || [],
      cpuResult.inningSummary || [],
      homeTeam.players,
      awayTeam.players,
      cpuResult.score.my,
      cpuResult.score.opp,
    );
    mergeAllTeamResultPatches(
      allTeamResultsPatch,
      buildAllTeamResultEntry(homeTeam.id, awayTeam.id, cpuResult, cpuBoxScore, homeTeam.name, awayTeam.name, safeSnapshot.gameDay),
    );
  }

  emitProgress(onProgress, '日次反映');
  ensureNotCancelled(isCancelled);

  const nextNews = [...(safeSnapshot.news || [])];
  const nextMailbox = [...(safeSnapshot.mailbox || [])];
  const nextSeasonHistory = {
    ...(safeSnapshot.seasonHistory && typeof safeSnapshot.seasonHistory === 'object' ? safeSnapshot.seasonHistory : {}),
  };
  const existingTransfers = Array.isArray(nextSeasonHistory.transfers) ? nextSeasonHistory.transfers : [];

  const newsTemplate = won ? NEWS_TEMPLATES_WIN : NEWS_TEMPLATES_LOSE;
  const scoreStr = `${userGameResult.score.my}-${userGameResult.score.opp}`;
  const headline = newsTemplate[rng(0, newsTemplate.length - 1)]
    .replace('{team}', myTeam.name || '自チーム')
    .replace('{opp}', currentOpp.name || '相手')
    .replace('{score}', scoreStr);
  nextNews.unshift({
    type: 'game',
    headline,
    source: 'スポーツ報知',
    dateLabel: `${safeSnapshot.year}年 ${safeSnapshot.gameDay}日目`,
    body: won
      ? `${myTeam.name}が${currentOpp.name}に${scoreStr}で勝利しました。`
      : `${myTeam.name}は${currentOpp.name}に${scoreStr}で敗れました。`,
  });

  if (Math.random() < 0.35) {
    nextNews.unshift({
      type: 'interview',
      headline: `インタビュー ${myTeam.name || ''}戦後会見`,
      source: '球団広報',
      dateLabel: `${safeSnapshot.year}年 ${safeSnapshot.gameDay}日目`,
      body: '試合後、監督にコメントを求められた。',
      question: (won ? INTERVIEW_QUESTIONS_WIN : INTERVIEW_QUESTIONS_LOSE)[rng(0, (won ? INTERVIEW_QUESTIONS_WIN : INTERVIEW_QUESTIONS_LOSE).length - 1)],
      options: won ? INTERVIEW_OPTIONS_WIN : INTERVIEW_OPTIONS_LOSE,
    });
  }

  const tradeOffer = tryGenerateCpuOfferSingleDay(nextTeams, safeSnapshot);
  if (tradeOffer) nextMailbox.unshift(tradeOffer);

  const tradeNews = tryCpuCpuDeadlineTradeSingleDay(nextTeams, safeSnapshot);
  if (tradeNews) {
    nextNews.unshift({
      type: 'trade',
      headline: tradeNews.headline,
      source: 'Baseball Times',
      dateLabel: `${safeSnapshot.year}年 ${safeSnapshot.gameDay}日目`,
      body: tradeNews.body,
    });
  }

  const retireAnnouncement = maybeBuildRetireAnnouncement(nextTeams[myTeamIndex], safeSnapshot.year, safeSnapshot.gameDay);
  if (retireAnnouncement?.news) {
    nextNews.unshift(retireAnnouncement.news);
  }

  let allStarPayload = null;
  let nextAllStarDone = !!safeSnapshot.allStarDone;
  let screenDirective = safeSnapshot.gameDay >= SEASON_GAMES ? 'playoff' : 'result';
  let finalizedTeams = finishFarmProgress(nextTeams,farmProgress,safeSnapshot.gameDay);

  if (!nextAllStarDone && safeSnapshot.gameDay + 1 === safeSnapshot.allStarTriggerDay) {
    const rosters = selectAllStars(nextTeams);
    const asResult = runAllStarGame(rosters, safeSnapshot.year);
    finalizedTeams = applyAllStarSelections(finalizedTeams, rosters);
    allStarPayload = { rosters, gameResult: asResult };
    nextAllStarDone = true;
    screenDirective = 'allstar';
    nextNews.unshift(...buildAllStarNewsItems(asResult, safeSnapshot.gameDay + 1, safeSnapshot.year));
  }

  const transferEntry = buildTransferEntry(tradeNews, safeSnapshot.year, safeSnapshot.gameDay);
  nextSeasonHistory.transfers = transferEntry
    ? [...existingTransfers, transferEntry].slice(-400)
    : existingTransfers;

  const nextState = {
    ...safeSnapshot,
    teams: finalizedTeams,
    ...(farmProgress ? {farmCompetition:farmProgress.competition,farmCompetitionVersion:1} : {}),
    seasonHistory: nextSeasonHistory,
    news: nextNews.slice(0, 1000),
    mailbox: nextMailbox.slice(0, 1000),
    gameDay: safeSnapshot.gameDay + 1,
    saveRevision: (Number(safeSnapshot.saveRevision) || 0) + 1,
    allStarDone: nextAllStarDone,
    allStarResult: allStarPayload || safeSnapshot.allStarResult || null,
  };

  emitProgress(onProgress, '完了', true);
  archiveChunker.flush();

  return {
    nextState,
    userGameResult: {
      ...userGameResult,
      oppTeam: currentOpp,
      won,
      gameNo: safeSnapshot.gameDay,
      isHome,
    },
    recentResultsPatch: [{
      won,
      drew,
      oppName: currentOpp.name || '',
      myScore: userGameResult.score.my,
      oppScore: userGameResult.score.opp,
      gameNo: safeSnapshot.gameDay,
    }],
    gameResultsMapPatch,
    allTeamResultsPatch,
    summaryCounts: {
      tradeMailCount: tradeOffer ? 1 : 0,
      foreignSigningCount: 0,
    },
    screenDirective,
    nextAllStarDone,
    allStarPayload,
    retireAnnouncement: retireAnnouncement?.modal || null,
  };
}
