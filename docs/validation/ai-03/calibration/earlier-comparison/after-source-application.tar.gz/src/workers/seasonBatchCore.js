import {prepareFarmProgress,finishFarmProgress} from '../engine/farmProgression';
import {selectFarmUsage} from '../engine/farmSelectors';
import { regularSeasonRequest } from '../engine/seasonProgress';
import { uid, rng, rngf, gameDayToDate } from '../utils';
import * as playerRules from '../engine/player';
import { applyRegularSeasonTeamUpdate } from '../engine/regularGameUpdates';
import { quickSimGame } from '../engine/simulation';
import { computeBoxScore } from '../engine/postGame';
import {
  createBattedBallArchiveChunker,
  createBattedBallBatchRecords,
} from '../engine/battedBallProfile';
import {
  generateCpuOffer,
  generateCpuCpuTrade,
  classifyTeam,
  evaluateFrontOfficePlan,
} from '../engine/trade';
import { selectAllStars, runAllStarGame } from '../engine/allstar';
import { getMyMatchup, getCpuMatchups } from '../engine/scheduleGen';
import { processCpuFaBids } from '../engine/contract';
import { executeCpuTrade } from '../engine/cpuTradeExecution';
import {
  SEASON_GAMES,
  NEWS_TEMPLATES_WIN,
  NEWS_TEMPLATES_LOSE,
  INTERVIEW_QUESTIONS_WIN,
  INTERVIEW_QUESTIONS_LOSE,
  INTERVIEW_OPTIONS_WIN,
  INTERVIEW_OPTIONS_LOSE,
  TRADE_DEADLINE_MONTH,
  TRADE_DEADLINE_PROB_EARLY,
  TRADE_DEADLINE_PROB_PEAK,
  TRADE_DEADLINE_CPU_CPU_PROB,
} from '../constants';
import {
  applyEmergencyRosterMaintenance,
  applyManagementPolicy,
  prepareTeamForGame,
  ROSTER_AUTOMATION_MODES,
} from '../engine/rosterAutomation';

const MAX_BATCH_BOX_SCORE_KEEP = 120;
const DEFAULT_PROGRESS_THROTTLE_MS = 250;
const DEFAULT_PROGRESS_PHASE = 'Simulating games';

export function createSeasonBatchProgressState(throttleMs = DEFAULT_PROGRESS_THROTTLE_MS) {
  return {
    throttleMs: Math.max(0, Number(throttleMs) || 0),
    lastEmitAt: null,
  };
}

export function shouldEmitSeasonBatchProgress(state, now, options = {}) {
  if (!state || typeof state !== 'object') return true;
  if (options.force) {
    state.lastEmitAt = now;
    return true;
  }
  if (state.lastEmitAt == null) {
    state.lastEmitAt = now;
    return true;
  }
  if ((now - state.lastEmitAt) >= state.throttleMs) {
    state.lastEmitAt = now;
    return true;
  }
  return false;
}

class SeasonBatchCancelledError extends Error {
  constructor() {
    super('Season batch simulation cancelled');
    this.name = 'SeasonBatchCancelledError';
  }
}

function cloneValue(value) {
  if (typeof structuredClone === 'function') {
    return structuredClone(value);
  }
  return JSON.parse(JSON.stringify(value));
}

function ensureNotCancelled(isCancelled) {
  if (typeof isCancelled === 'function' && isCancelled()) {
    throw new SeasonBatchCancelledError();
  }
}

function emitProgress({
  progressState,
  startedAt,
  current,
  total,
  phase,
  onProgress,
  force = false,
}) {
  if (typeof onProgress !== 'function') return;
  const now = Date.now();
  if (!shouldEmitSeasonBatchProgress(progressState, now, { force })) return;
  const safeTotal = Math.max(1, Number.isFinite(total) ? Math.floor(total) : 1);
  const safeCurrent = Math.max(0, Math.min(safeTotal, Number.isFinite(current) ? Math.floor(current) : 0));
  const elapsedMs = Math.max(0, now - startedAt);
  const avgMsPerGame = safeCurrent > 0 ? elapsedMs / safeCurrent : 0;
  const etaSec = safeCurrent >= safeTotal ? 0 : ((safeTotal - safeCurrent) * avgMsPerGame) / 1000;
  onProgress({
    current: safeCurrent,
    total: safeTotal,
    avgMsPerGame: Number.isFinite(avgMsPerGame) ? Math.max(0, avgMsPerGame) : 0,
    etaSec: Number.isFinite(etaSec) ? Math.max(0, etaSec) : 0,
    phase: typeof phase === 'string' && phase.trim() ? phase : DEFAULT_PROGRESS_PHASE,
  });
}


function applyDhToTeam(team, useDh) {
  return prepareTeamForGame(team, useDh);
}

function calcLeagueRank(teamId, allTeams, league) {
  const sameLeague = [...allTeams.filter((team) => team.league === league)]
    .sort((a, b) => {
      const pa = a.wins / Math.max(1, a.wins + a.losses);
      const pb = b.wins / Math.max(1, b.wins + b.losses);
      return pb - pa || (b.rf - b.ra) - (a.rf - a.ra);
    });
  return sameLeague.findIndex((team) => team.id === teamId) + 1;
}

function tryCpuCpuDeadlineTrade(teamsArr, currentGameDay, schedule, myId) {
  const currentDate = gameDayToDate(currentGameDay, schedule);
  if (!currentDate || currentDate.month !== TRADE_DEADLINE_MONTH) return null;
  if (rngf(0, 1) > TRADE_DEADLINE_CPU_CPU_PROB) return null;

  teamsArr.forEach((team) => {
    team.frontOfficePlan = evaluateFrontOfficePlan(team, teamsArr, currentGameDay);
  });
  const result = generateCpuCpuTrade(teamsArr.filter((team) => team.id !== myId));
  if (!result) return null;

  const {
    buyerId,
    sellerId,
    buyerGets,
    sellerGets,
    buyerName,
    sellerName,
  } = result;
  const buyer = teamsArr.find((team) => team.id === buyerId);
  const seller = teamsArr.find((team) => team.id === sellerId);
  if (!buyer || !seller) return null;

  if (!executeCpuTrade(teamsArr, result, currentGameDay)) return null;

  return {
    headline: `移籍情報 ${buyerGets.name} が${buyerName}へ`,
    body: `${sellerName} と ${buyerName} の間でトレードが成立。${buyerName} は ${buyerGets.name} を獲得し、${sellerGets.name} を放出した。`,
    buyerName,
    sellerName,
    buyerGetsName: buyerGets.name,
    sellerGetsName: sellerGets.name,
  };
}

function tryGenerateCpuOfferInBatch(teamsArr, currentGameDay, existingOfferCount, snapshot) {
  const liveMyTeam = teamsArr.find((team) => team.id === snapshot.myId);
  if (!liveMyTeam) return null;
  const currentDate = gameDayToDate(currentGameDay, snapshot.schedule);
  if (currentDate && currentDate.month > TRADE_DEADLINE_MONTH) return null;

  let prob = 0.15;
  if (currentDate && currentDate.month === TRADE_DEADLINE_MONTH) {
    prob = currentDate.day > 15 ? TRADE_DEADLINE_PROB_PEAK : TRADE_DEADLINE_PROB_EARLY;
  }
  if (rngf(0, 1) > prob || existingOfferCount >= 2) return null;

  const others = teamsArr.filter((team) => team.id !== snapshot.myId);
  others.forEach((team) => {
    team.frontOfficePlan = evaluateFrontOfficePlan(team, teamsArr, currentGameDay);
  });
  if (!others.length) return null;

  let cpuTeam;
  if (currentDate && currentDate.month === TRADE_DEADLINE_MONTH) {
    const buyers = others.filter((team) => classifyTeam(team, teamsArr) === 'buyer');
    cpuTeam = buyers.length ? buyers[rng(0, buyers.length - 1)] : others[rng(0, others.length - 1)];
  } else {
    cpuTeam = others[rng(0, others.length - 1)];
  }

  const offer = generateCpuOffer(cpuTeam, liveMyTeam);
  if (!offer) return null;
  return {
    id: uid(),
    type: 'trade',
    title: `${offer.from.name} からトレードオファー`,
    from: offer.from.name,
    dateLabel: `${snapshot.year}年 ${currentGameDay}日目`,
    timestamp: Date.now(),
    read: false,
    resolved: false,
    body: `${offer.from.name} sent a trade offer.\n\nWanted players: ${offer.want.map((player) => player.name).join(' / ')}\nOffered players: ${offer.offer.length > 0 ? offer.offer.map((player) => player.name).join(' / ') : 'None'}${offer.cash > 0 ? `\nCash: +${(offer.cash / 10000).toLocaleString()} x10k` : ''}\n\nCheck the mailbox for details.`, 
    offer,
  };
}

function tryCpuForeignFaInBatch(teamsArr, currentGameDay, pool, snapshot) {
  if (!pool.length) {
    return { updatedTeams: teamsArr, remainingFaPool: pool, news: null, claimed: [] };
  }
  const foreignPool = pool.filter((player) => player.isForeign);
  if (!foreignPool.length) {
    return { updatedTeams: teamsArr, remainingFaPool: pool, news: null, claimed: [] };
  }
  const result = processCpuFaBids(teamsArr, snapshot.myId, foreignPool, teamsArr, snapshot.year);
  if (result.remainingFaPool.length === foreignPool.length) {
    return { updatedTeams: teamsArr, remainingFaPool: pool, news: null, claimed: [] };
  }
  const signedIdSet = new Set(
    foreignPool
      .filter((player) => !result.remainingFaPool.some((remaining) => remaining.id === player.id))
      .map((player) => player.id),
  );
  const mergedPool = pool.filter((player) => !signedIdSet.has(player.id));
  const news = (result.news || []).map((item) => ({
    ...item,
    dateLabel: `${snapshot.year}年 ${currentGameDay}日目`,
  }));
  return {
    updatedTeams: result.updatedTeams,
    remainingFaPool: mergedPool,
    news,
    claimed: result.claimed || [],
  };
}

function applyAllStarSelections(baseTeams, rosters) {
  const pickedIds = new Set([...(rosters?.ce || []), ...(rosters?.pa || [])].map((player) => player.id));
  return baseTeams.map((team) => ({
    ...team,
    players: (team.players || []).map((player) => (
      pickedIds.has(player.id)
        ? { ...player, allStarSelections: (player.allStarSelections || 0) + 1 }
        : player
    )),
  }));
}

function buildAllStarNewsItems(asResult, dayLabel, year) {
  if (!asResult) return [];
  return [
    {
      type: 'allstar',
      headline: `All-Star Game 1 CE ${asResult.game1.score.ce} - PA ${asResult.game1.score.pa}`,
      source: 'NPB Official',
      dateLabel: `${year} Day ${dayLabel}`,
      body: `Venue: ${asResult.venue}\nCE ${asResult.game1.score.ce} - ${asResult.game1.score.pa} PA\nMVP: ${asResult.game1.mvp?.name || 'None'}`,
    },
    {
      type: 'allstar',
      headline: `All-Star Game 2 CE ${asResult.game2.score.ce} - PA ${asResult.game2.score.pa}`,
      source: 'NPB Official',
      dateLabel: `${year} Day ${dayLabel + 1}`,
      body: `CE ${asResult.game2.score.ce} - ${asResult.game2.score.pa} PA\nMVP: ${asResult.game2.mvp?.name || 'None'}`,
    },
  ];
}

function makeCompactBoxScoreRecord({ homeId, awayId, dayNo, cr, bs, homeName, awayName }) {
  return {
    homeId,
    awayId,
    dayNo,
    gameResult: {
      won: cr.won,
      score: {
        my: cr.score.my,
        opp: cr.score.opp,
      },
    },
    homeName,
    awayName,
    inningScores: bs?.inningScores,
    homeBatting: bs?.homeBatting,
    awayBatting: bs?.awayBatting,
    homePitching: bs?.homePitching,
    awayPitching: bs?.awayPitching,
  };
}

function makeTeamResultSummary({ won, drew, myScore, oppScore, oppName, oppId, homeId, awayId }) {
  return {
    won,
    drew,
    myScore,
    oppScore,
    oppName,
    oppId,
    homeId,
    awayId,
  };
}

function buildRecentResult(gameResult) {
  return {
    won: gameResult.won,
    drew: gameResult.score.my === gameResult.score.opp,
    oppName: gameResult.oppTeam?.name || '',
    myScore: gameResult.score.my,
    oppScore: gameResult.score.opp,
    gameNo: gameResult.gameNo,
  };
}

function buildBatchResultSummary(gameResult) {
  return {
    gameNo: gameResult.gameNo,
    won: gameResult.won,
    drew: gameResult.score.my === gameResult.score.opp,
    score: {
      my: gameResult.score.my,
      opp: gameResult.score.opp,
    },
    oppTeam: gameResult.oppTeam
      ? {
          id: gameResult.oppTeam.id,
          name: gameResult.oppTeam.name,
          short: gameResult.oppTeam.short,
          emoji: gameResult.oppTeam.emoji,
          color: gameResult.oppTeam.color,
        }
      : null,
  };
}

function compactBatchLogEntry(entry) {
  if (!entry || typeof entry !== 'object') return null;
  return {
    inning: Number(entry.inning) || 0,
    isTop: Boolean(entry.isTop),
    batter: typeof entry.batter === 'string' ? entry.batter : '?',
    batId: entry.batId ?? null,
    pitcherId: entry.pitcherId ?? null,
    result: typeof entry.result === 'string' ? entry.result : '',
    type: typeof entry.type === 'string' ? entry.type : undefined,
    rbi: Number(entry.rbi) || 0,
    outs: Number(entry.outs) || 0,
    bases: Array.isArray(entry.bases) ? entry.bases.slice(0, 3) : [],
    pitches: Number(entry.pitches) || 0,
    isIntentional: Boolean(entry.isIntentional),
    strategy: typeof entry.strategy === 'string' ? entry.strategy : undefined,
    scorer: Boolean(entry.scorer),
    isStolenBase: Boolean(entry.isStolenBase),
    pitchType: typeof entry.pitchType === 'string' ? entry.pitchType : undefined,
    zone: typeof entry.zone === 'string' ? entry.zone : undefined,
    scorers: Array.isArray(entry.scorers) ? entry.scorers.slice(0, 4) : [],
  };
}

function buildBatchOpponentSnapshot(team, log) {
  const participantIds = new Set();
  for (const entry of log || []) {
    if (entry?.scorer === false && entry.batId != null) participantIds.add(entry.batId);
    if (entry?.scorer === true && entry.pitcherId != null) participantIds.add(entry.pitcherId);
  }
  const sourcePlayers = [...(team?.players || []), ...(team?.farm || [])];
  const players = sourcePlayers
    .filter((player) => participantIds.has(player.id))
    .map((player) => ({
      id: player.id,
      name: player.name,
      stats: {
        AB: Number(player?.stats?.AB) || 0,
        H: Number(player?.stats?.H) || 0,
      },
    }));
  return {
    id: team?.id,
    name: team?.name || '',
    short: team?.short || '',
    emoji: team?.emoji || '',
    color: team?.color || '',
    players,
    farm: [],
  };
}

function buildBatchGameResult(sim, won, oppTeam, gameNo, isHome) {
  const compactLog = (sim?.log || []).map(compactBatchLogEntry).filter(Boolean);
  return {
    score: {
      my: Number(sim?.score?.my) || 0,
      opp: Number(sim?.score?.opp) || 0,
    },
    won: Boolean(won),
    log: compactLog,
    inningSummary: (sim?.inningSummary || []).map((inning) => ({
      inning: Number(inning?.inning) || 0,
      isTop: Boolean(inning?.isTop),
      runs: Number(inning?.runs) || 0,
    })),
    oppTeam: buildBatchOpponentSnapshot(oppTeam, compactLog),
    gameNo,
    isHome: isHome !== false,
  };
}

function buildGameResultsMapPatch(gameResults) {
  const patch = {};
  gameResults.forEach((result) => {
    patch[result.gameNo] = {
      won: result.won,
      drew: result.score.my === result.score.opp,
      isHome: result.isHome !== false,
      oppName: result.oppTeam?.name || '',
      myScore: result.score.my,
      oppScore: result.score.opp,
      log: result.log || [],
      inningSummary: result.inningSummary || [],
      oppTeam: result.oppTeam,
    };
  });
  return patch;
}

function buildAllTeamResultsPatch(batchBoxScores) {
  const patches = {};
  for (const box of batchBoxScores) {
    const hWon = box.gameResult.won;
    const drew = box.gameResult.score.my === box.gameResult.score.opp;
    if (!patches[box.homeId]) patches[box.homeId] = {};
    patches[box.homeId][box.dayNo] = makeTeamResultSummary({
      won: hWon,
      drew,
      myScore: box.gameResult.score.my,
      oppScore: box.gameResult.score.opp,
      oppName: box.awayName,
      oppId: box.awayId,
      homeId: box.homeId,
      awayId: box.awayId,
    });
    if (!patches[box.awayId]) patches[box.awayId] = {};
    patches[box.awayId][box.dayNo] = makeTeamResultSummary({
      won: !hWon && !drew,
      drew,
      myScore: box.gameResult.score.opp,
      oppScore: box.gameResult.score.my,
      oppName: box.homeName,
      oppId: box.homeId,
      homeId: box.homeId,
      awayId: box.awayId,
    });
  }
  return patches;
}

function buildAllTeamBoxScoresPatch(batchBoxScores) {
  const patches = {};
  for (const box of batchBoxScores) {
    const hasDetail = (box.inningScores && box.inningScores.length)
      || (box.homeBatting && box.homeBatting.length)
      || (box.awayBatting && box.awayBatting.length)
      || (box.homePitching && box.homePitching.length)
      || (box.awayPitching && box.awayPitching.length);
    if (!hasDetail) continue;
    if (!patches[box.homeId]) patches[box.homeId] = {};
    patches[box.homeId][box.dayNo] = {
      inningScores: box.inningScores,
      myBatting: box.homeBatting,
      oppBatting: box.awayBatting,
      myPitching: box.homePitching,
      oppPitching: box.awayPitching,
    };
    if (!patches[box.awayId]) patches[box.awayId] = {};
    patches[box.awayId][box.dayNo] = {
      inningScores: box.inningScores,
      myBatting: box.awayBatting,
      oppBatting: box.homeBatting,
      myPitching: box.awayPitching,
      oppPitching: box.homePitching,
    };
  }
  return patches;
}

function normalizeSnapshot(snapshot) {
  const safeSnapshot = snapshot && typeof snapshot === 'object' ? snapshot : {};
  return {
    ...safeSnapshot,
    teams: cloneValue(safeSnapshot.teams || []),
    schedule: cloneValue(safeSnapshot.schedule || []),
    faPool: cloneValue(safeSnapshot.faPool || []),
    seasonHistory: cloneValue(safeSnapshot.seasonHistory || {}),
    news: cloneValue(safeSnapshot.news || []),
    mailbox: cloneValue(safeSnapshot.mailbox || []),
  };
}

function buildTeamMap(teams) {
  return new Map((teams || []).map((team) => [team.id, team]));
}

export function simulateSeasonBatch({
  snapshot,
  count,
  autoManageMyTeam = false,
  onProgress,
  onArchiveChunk,
  isCancelled,
}) {
  const request = regularSeasonRequest(snapshot, count);
  if (!request.count) throw new Error(request.reason);
  const state = normalizeSnapshot(snapshot);
  const myTeamBefore = state.teams.find((team) => team.id === state.myId);
  if (!myTeamBefore) {
    throw new Error('My team was not found in snapshot');
  }

  const safeCount = request.count;
  if (safeCount <= 0) {
    throw new Error('Season batch count must be greater than zero');
  }

  const startedAt = Date.now();
  const progressState = createSeasonBatchProgressState();
  const archiveChunker = createBattedBallArchiveChunker(onArchiveChunk);
  const archiveGame = (log, gameDay, firstTeam, secondTeam) => {
    const gameId = `${gameDay}:${firstTeam?.id ?? 'team1'}:${secondTeam?.id ?? 'team2'}`;
    archiveChunker.add(createBattedBallBatchRecords(log, {
      saveId: state.saveId,
      year: state.year,
      gameDay,
      gameId,
      teams: [firstTeam, secondTeam],
      source: 'worker',
    }));
  };
  emitProgress({
    progressState,
    startedAt,
    current: 0,
    total: safeCount,
    phase: DEFAULT_PROGRESS_PHASE,
    onProgress,
    force: true,
  });

  let newTeams = state.teams;
  let newDay = state.gameDay;
  let newFaPool = state.faPool;
  let allStarDoneLocal = !!state.allStarDone;
  let allStarPayload = null;

  const results = [];
  const batchTradeMails = [];
  const batchForeignSignNews = [];
  const batchForeignSignings = [];
  const batchNewsItems = [];
  let batchAllStarNewsItems = [];
  const batchBoxScores = [];
  const batchInjuries = [];
  const cpuHighlights = [];

  const beforeRank = calcLeagueRank(state.myId, newTeams, myTeamBefore.league);
  const beforeRecord = {
    w: myTeamBefore.wins,
    l: myTeamBefore.losses,
    d: myTeamBefore.draws ?? 0,
  };
  const pendingTradeCountBase = (state.mailbox || []).filter((mail) => mail.type === 'trade' && !mail.resolved).length;

  for (let index = 0; index < safeCount; index += 1) {
    ensureNotCancelled(isCancelled);

    const farmUsage = selectFarmUsage(state.farmCompetition);
    newTeams = newTeams.map((team) => {
      if (team.id === state.myId && !autoManageMyTeam) {
        return applyEmergencyRosterMaintenance(team);
      }
      return applyManagementPolicy(team, {
        teams: newTeams,
        gameDay: newDay,
        includeRosterChanges: true,
        automationMode: ROSTER_AUTOMATION_MODES.FULL,
        farmUsage,
      });
    });

    const farmProgress = prepareFarmProgress(state,newTeams,newDay);
    let teamMap = buildTeamMap(newTeams);

    const scheduleMatchup = getMyMatchup(state.schedule, newDay, state.myId);
    const oppId = scheduleMatchup?.oppId;
    const opp = scheduleMatchup ? teamMap.get(oppId) : null;
    const cpuPairs = getCpuMatchups(state.schedule, newDay, state.myId, oppId);

    for (const cpuMatchup of cpuPairs) {
      const homeTeam = teamMap.get(cpuMatchup.homeId);
      const awayTeam = teamMap.get(cpuMatchup.awayId);
      if (!homeTeam || !awayTeam) continue;
      const useDh = !!homeTeam.dhEnabled;
      const homePlayersSnap = [...homeTeam.players];
      const awayPlayersSnap = [...awayTeam.players];
      const sim = quickSimGame(
        applyDhToTeam(homeTeam, useDh),
        applyDhToTeam(awayTeam, useDh),
        { compactLogs: true },
      );
      archiveGame(sim.log, newDay, homeTeam, awayTeam);
      const box = computeBoxScore(sim.log || [], sim.inningSummary || [], homePlayersSnap, awayPlayersSnap, sim.score.my, sim.score.opp);
      batchBoxScores.push(makeCompactBoxScoreRecord({
        homeId: homeTeam.id,
        awayId: awayTeam.id,
        dayNo: newDay,
        cr: sim,
        bs: box,
        homeName: homeTeam.name,
        awayName: awayTeam.name,
      }));
      if (batchBoxScores.length > MAX_BATCH_BOX_SCORE_KEEP) {
        batchBoxScores.splice(0, batchBoxScores.length - MAX_BATCH_BOX_SCORE_KEEP);
      }

      const drew = sim.score.my === sim.score.opp;
      const homeWon = sim.won;
      const margin = Math.abs(sim.score.my - sim.score.opp);
      if (!drew && (margin >= 4 || margin <= 1) && cpuHighlights.length < 8) {
        cpuHighlights.push({
          homeTeam: { short: homeTeam.short, emoji: homeTeam.emoji, color: homeTeam.color },
          awayTeam: { short: awayTeam.short, emoji: awayTeam.emoji, color: awayTeam.color },
          homeScore: sim.score.my,
          awayScore: sim.score.opp,
          homeWon,
          label: margin >= 4 ? 'Blowout' : 'Close game',
        });
      }

      Object.assign(homeTeam, applyRegularSeasonTeamUpdate(homeTeam, sim, { isFirstTeam: true, isHomeTeam: true, gameDay: newDay, year: state.year }, playerRules).team);
      Object.assign(awayTeam, applyRegularSeasonTeamUpdate(awayTeam, sim, { isFirstTeam: false, isHomeTeam: false, gameDay: newDay, year: state.year }, playerRules).team);
    }

    const foreignFaResult = tryCpuForeignFaInBatch(newTeams, newDay, newFaPool, state);
    newTeams = foreignFaResult.updatedTeams;
    newFaPool = foreignFaResult.remainingFaPool;
    teamMap = buildTeamMap(newTeams);
    if (foreignFaResult.news?.length) {
      batchForeignSignNews.push(...foreignFaResult.news);
    }
    if (foreignFaResult.claimed?.length) {
      batchForeignSignings.push(...foreignFaResult.claimed);
    }

    const myTeam = teamMap.get(state.myId);
    if (scheduleMatchup && opp && myTeam) {
      const useDh = scheduleMatchup.isHome ? !!myTeam.dhEnabled : !!opp.dhEnabled;
      const sim = quickSimGame(
        applyDhToTeam(myTeam, useDh),
        applyDhToTeam(opp, useDh),
        { isMyHome: scheduleMatchup.isHome, compactLogs: true },
      );
      archiveGame(sim.log, newDay, myTeam, opp);
      const homePerspectiveSim = scheduleMatchup.isHome
        ? sim
        : {
            ...sim,
            won: sim.score.opp > sim.score.my,
            score: { my: sim.score.opp, opp: sim.score.my },
          };
      batchBoxScores.push(makeCompactBoxScoreRecord({
        homeId: scheduleMatchup.isHome ? myTeam.id : opp.id,
        awayId: scheduleMatchup.isHome ? opp.id : myTeam.id,
        dayNo: newDay,
        cr: homePerspectiveSim,
        bs: null,
        homeName: scheduleMatchup.isHome ? myTeam.name : opp.name,
        awayName: scheduleMatchup.isHome ? opp.name : myTeam.name,
      }));
      if (batchBoxScores.length > MAX_BATCH_BOX_SCORE_KEEP) {
        batchBoxScores.splice(0, batchBoxScores.length - MAX_BATCH_BOX_SCORE_KEEP);
      }

      const won = sim.score.my > sim.score.opp;
      const myUpdate = applyRegularSeasonTeamUpdate(myTeam, sim, { isFirstTeam: true, isHomeTeam: scheduleMatchup.isHome, gameDay: newDay, year: state.year }, playerRules);
      myUpdate.injuries.forEach(injury => {
        const player = myUpdate.team.players.find(p => p.id === injury.id);
        if (player) batchInjuries.push({ name: player.name, pos: player.pos, type: injury.type, days: injury.days, part: injury.part });
      });
      Object.assign(myTeam, applyEmergencyRosterMaintenance(myUpdate.team));
      const oppTeam = teamMap.get(opp.id);
      if (oppTeam) Object.assign(oppTeam, applyRegularSeasonTeamUpdate(oppTeam, sim, { isFirstTeam: false, isHomeTeam: !scheduleMatchup.isHome, gameDay: newDay, year: state.year }, playerRules).team);

      results.push(buildBatchGameResult(sim, won, opp, newDay, scheduleMatchup.isHome));

      const templates = won ? NEWS_TEMPLATES_WIN : NEWS_TEMPLATES_LOSE;
      const scoreString = `${sim.score.my}-${sim.score.opp}`;
      const myTeamName = newTeams.find((team) => team.id === state.myId)?.name || '自チーム';
      const headline = templates[rng(0, templates.length - 1)]
        .replace('{team}', myTeamName)
        .replace('{opp}', opp.name || 'Opponent')
        .replace('{score}', scoreString);
      batchNewsItems.push({
        type: 'game',
        headline,
        source: 'スポーツ報知',
        dateLabel: `${state.year}年 ${newDay}日目`,
        body: won
          ? `${myTeamName} が${opp.name} に ${scoreString} で勝利した。`
          : `${myTeamName} は ${opp.name} に ${scoreString} で敗れた。`,
      });
      if (rngf(0, 1) < 0.15) {
        const questions = won ? INTERVIEW_QUESTIONS_WIN : INTERVIEW_QUESTIONS_LOSE;
        const options = won ? INTERVIEW_OPTIONS_WIN : INTERVIEW_OPTIONS_LOSE;
        batchNewsItems.push({
          type: 'interview',
          headline: `インタビュー ${myTeamName} 監督に直撃`,
          source: '記者会見',
          dateLabel: `${state.year}年 ${newDay}日目`,
          body: '試合後の監督インタビューです。',
          question: questions[rng(0, questions.length - 1)],
          options,
        });
      }
    }

    if(farmProgress) {
      newTeams=finishFarmProgress(newTeams,farmProgress,newDay);
      state.farmCompetition=farmProgress.competition;state.farmCompetitionVersion=1;
    }
    // Finish every scheduled game before changing CPU ownership. Otherwise an
    // opponent can lose a starter between morning roster checks and its game,
    // or a transferred player can appear for two teams on the same day.
    const cpuCpuTradeNews = tryCpuCpuDeadlineTrade(newTeams, newDay, state.schedule, state.myId);
    if (cpuCpuTradeNews) results.push({ type: 'trade_news', ...cpuCpuTradeNews, day: newDay });
    const tradeMail = tryGenerateCpuOfferInBatch(newTeams, newDay, pendingTradeCountBase + batchTradeMails.length, state);
    if (tradeMail) batchTradeMails.push(tradeMail);

    if (!allStarDoneLocal && newDay === state.allStarTriggerDay) {
      const rosters = selectAllStars(newTeams);
      const gameResult = runAllStarGame(rosters, state.year);
      newTeams = applyAllStarSelections(newTeams, rosters);
      allStarDoneLocal = true;
      allStarPayload = { rosters, gameResult };
      batchAllStarNewsItems = buildAllStarNewsItems(gameResult, newDay, state.year);
    }

    newDay += 1;

    emitProgress({
      progressState,
      startedAt,
      current: index + 1,
      total: safeCount,
      phase: DEFAULT_PROGRESS_PHASE,
      onProgress,
    });
  }

  ensureNotCancelled(isCancelled);
  archiveChunker.flush();
  emitProgress({
    progressState,
    startedAt,
    current: safeCount,
    total: safeCount,
    phase: 'Finalizing results',
    onProgress,
    force: true,
  });

  const tradeNewsItems = results
    .filter((result) => result.type === 'trade_news')
    .map((result) => ({
      type: 'trade',
      headline: result.headline,
      source: 'Baseball Times',
      dateLabel: `${state.year}年 ${result.day}日目`,
      body: result.body,
    }));
  const transferEntries = results
    .filter((result) => result.type === 'trade_news')
    .map((result) => ({
      id: uid(),
      timestamp: Date.now(),
      year: state.year,
      day: result.day,
      type: 'trade',
      headline: `CPU間トレード ${result.sellerName} -> ${result.buyerName}`,
      fromTeam: result.sellerName,
      toTeam: result.buyerName,
      playersIn: [result.buyerGetsName],
      playersOut: [result.sellerGetsName],
      detail: result.body,
    }));
  const gameNewsItems = [...batchNewsItems].reverse();
  const allStarNewsItems = [...batchAllStarNewsItems];
  const nowTimestamp = Date.now();
  const normalizedBatchNews = [...tradeNewsItems, ...gameNewsItems, ...batchForeignSignNews, ...allStarNewsItems]
    .map((item, newsIndex) => ({
      ...item,
      id: uid(),
      timestamp: nowTimestamp - newsIndex,
    }));
  const nextNews = [...normalizedBatchNews, ...(state.news || [])].slice(0, 50);

  let nextMailbox = batchTradeMails.length ? [...(state.mailbox || []), ...batchTradeMails] : [...(state.mailbox || [])];
  if (batchForeignSignings.length) {
    const byTeam = new Map();
    for (const claim of batchForeignSignings) {
      if (!byTeam.has(claim.teamId)) {
        byTeam.set(claim.teamId, {
          teamId: claim.teamId,
          teamName: claim.teamName,
          teamEmoji: claim.teamEmoji,
          players: [],
        });
      }
      byTeam.get(claim.teamId).players.push(`${claim.player.name} (${claim.player.pos})`);
    }
    nextMailbox = [
      ...nextMailbox,
      {
        id: uid(),
        type: 'cpu_fa_summary',
        read: false,
        title: `外国人補強まとめ ${byTeam.size}件`,
        subject: `外国人補強まとめ ${byTeam.size}件`,
        from: 'スカウト部',
        dateLabel: `${state.year}年 ${newDay - 1}日目まで`,
        timestamp: Date.now(),
        body: 'CPU球団による外国人選手の補強状況をまとめました。',
        signings: Array.from(byTeam.values()),
      },
    ];
  }

  const existingSeasonHistory = state.seasonHistory && typeof state.seasonHistory === 'object' ? state.seasonHistory : {};
  const existingTransfers = Array.isArray(existingSeasonHistory.transfers) ? existingSeasonHistory.transfers : [];
  const nextSeasonHistory = {
    ...existingSeasonHistory,
    transfers: [...existingTransfers, ...transferEntries].slice(-400),
  };

  const gameResults = results.filter((result) => result.type !== 'trade_news');
  const afterMyTeam = newTeams.find((team) => team.id === state.myId);
  const afterRecord = afterMyTeam
    ? { w: afterMyTeam.wins, l: afterMyTeam.losses, d: afterMyTeam.draws ?? 0 }
    : { w: 0, l: 0, d: 0 };
  const afterRank = afterMyTeam ? calcLeagueRank(state.myId, newTeams, afterMyTeam.league) : beforeRank;

  const nextState = {
    ...state,
    teams: newTeams,
    gameDay: newDay,
    faPool: newFaPool,
    seasonHistory: nextSeasonHistory,
    news: nextNews,
    mailbox: nextMailbox,
    saveRevision: (Number(state.saveRevision) || 0) + 1,
    allStarDone: allStarDoneLocal,
    allStarResult: allStarPayload?.gameResult ?? state.allStarResult ?? null,
  };

  emitProgress({
    progressState,
    startedAt,
    current: safeCount,
    total: safeCount,
    phase: 'Done',
    onProgress,
    force: true,
  });

  return {
    nextState,
    batchResults: gameResults.map(buildBatchResultSummary),
    batchMeta: {
      beforeRank,
      afterRank,
      beforeRecord,
      afterRecord,
      injuries: batchInjuries,
      cpuHighlights,
    },
    recentResults: gameResults.map(buildRecentResult).reverse().slice(0, 5),
    gameResultsMapPatch: buildGameResultsMapPatch(gameResults),
    allTeamResultsPatch: buildAllTeamResultsPatch(batchBoxScores),
    allTeamBoxScoresPatch: buildAllTeamBoxScoresPatch(batchBoxScores),
    nextAllStarDone: allStarDoneLocal,
    allStarPayload,
    summaryCounts: {
      tradeMailCount: batchTradeMails.length,
      foreignSigningCount: batchForeignSignings.length,
    },
    shouldEnterPlayoff: (newDay - 1) >= SEASON_GAMES,
  };
}

export { SeasonBatchCancelledError };
