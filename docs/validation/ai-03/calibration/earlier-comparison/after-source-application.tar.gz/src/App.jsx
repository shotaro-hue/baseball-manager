import {migrateFarmCompetition} from './engine/farmMigration';
import './styles.css';
import { SEASON_PARAMS, getDefaultParams } from './data/scheduleParams.js';
import { FOREIGN_FA_COUNT_MIN, FOREIGN_FA_COUNT_MAX } from './constants';
import { rng } from './utils';
import { useGameState } from './hooks/useGameState';
import { useSeasonFlow } from './hooks/useSeasonFlow';
import { useOffseason } from './hooks/useOffseason';
import AppScreenRouter from './components/AppScreenRouter';
import HubShell from './components/hub/HubShell';
import { planningResumeScreen } from './engine/offseasonPlanning';

let appSaveModulePromise = null;
let appScheduleModulePromise = null;
let appPlayerModulePromise = null;

function loadAppSaveModule() {
  if (!appSaveModulePromise) appSaveModulePromise = import('./engine/saveload');
  return appSaveModulePromise;
}

function loadAppScheduleModule() {
  if (!appScheduleModulePromise) appScheduleModulePromise = import('./engine/scheduleGen');
  return appScheduleModulePromise;
}

function loadAppPlayerModule() {
  if (!appPlayerModulePromise) appPlayerModulePromise = import('./engine/player');
  return appPlayerModulePromise;
}

export default function App() {
  const gs = useGameState();
  const sf = useSeasonFlow(gs);
  const os = useOffseason(gs);

  const handleLoad = async () => {
    if (gs.isNewGameInitializing()) return;
    const attempt = gs.getNewGameInitializationAttempt();
    const loadIsStale = () => gs.isNewGameInitializing() || attempt !== gs.getNewGameInitializationAttempt();
    return gs.runTitleLoad(async () => {
      try {
        const [{ loadGame, getLastLoadResult }, scheduleMod, playerMod] = await Promise.all([
          loadAppSaveModule(),
          loadAppScheduleModule(),
          loadAppPlayerModule(),
        ]);
        if (loadIsStale()) return;
        const saved = await loadGame();
        if (loadIsStale()) return;
        if (!saved) {
          gs.notify(getLastLoadResult?.().status === 'unrecoverable' ? 'セーブとバックアップを復旧できませんでした。必要な履歴が欠損・破損しています。' : 'セーブデータが見つかりません', 'warn');
          return;
        }

        const normalizedTeams = (saved.teams || []).map((team) => {
          const nonPitcherIds = (team.players || [])
            .filter((player) => !player.isPitcher)
            .map((player) => player.id);
          const fallback = (team.lineup || []).filter((id) =>
            nonPitcherIds.includes(id),
          );
          const lineupNoDh = (team.lineupNoDh || fallback)
            .filter((id) => nonPitcherIds.includes(id))
            .slice(0, 8);
          const lineupDh = (team.lineupDh || fallback)
            .filter((id) => nonPitcherIds.includes(id))
            .slice(0, 9);
          const rosterDhMode = team.rosterDhMode ?? team.dhEnabled ?? false;
          return {
            ...team,
            lineupNoDh,
            lineupDh,
            rosterDhMode,
            lineup: (rosterDhMode ? lineupDh : lineupNoDh).slice(),
          };
        });

        const loadedSchedule = saved.schedule ?? scheduleMod.generateSeasonSchedule(saved.year, normalizedTeams);
        const migrated = migrateFarmCompetition({...saved,teams:normalizedTeams,schedule:loadedSchedule});

        const loadedParams = SEASON_PARAMS[saved.year] || getDefaultParams(saved.year);
        const loadedAllStarTriggerDay = scheduleMod.calcAllStarTriggerDay(loadedSchedule, loadedParams.allStarSkipDates);

        const openingForeignPool = playerMod.generateForeignFaPool(
          rng(FOREIGN_FA_COUNT_MIN, FOREIGN_FA_COUNT_MAX),
        );
        const shouldBackfillForeignFa =
          (saved.faPool?.length ?? 0) === 0 && saved.gameDay === 1;
        gs.applyProgressCandidate(migrated);
        gs.setMyId(saved.myId);
        gs.setSaveId(saved.saveId);
        gs.setGameDay(saved.gameDay);
        gs.setYear(saved.year);
        gs.setOffseasonPlan(planningResumeScreen(saved.offseasonPlan, saved.year, saved.myId) === 'hub' ? null : saved.offseasonPlan);

        gs.setSchedule(loadedSchedule);
        gs.setAllStarTriggerDay(loadedAllStarTriggerDay);
        gs.setFaPool(shouldBackfillForeignFa ? openingForeignPool : saved.faPool || []);
        gs.setFaYears(saved.faYears || {});
        gs.hydrateLargeSaveData({
          seasonHistory: saved.seasonHistory || {
            awards: [],
            records: {
              singleSeasonHR: null,
              singleSeasonAVG: null,
              singleSeasonK: null,
              careerHR: {},
              careerW: {},
            },
            hallOfFame: [],
            championships: [],
            standingsHistory: [],
            transfers: [],
          },
          news: saved.news || [],
          mailbox: saved.mailbox || [],
        });
        gs.hydrateMatchHistory(saved);
        gs.setSaveRevision(Number(saved.saveRevision) || 0);
        gs.resetSaveTracking();
        gs.setCpuTradeOffers([]);

        sf.setPlayoff(null);
        os.resetTransientOffseason();

        gs.setTab('dashboard');
        gs.setScreen(planningResumeScreen(saved.offseasonPlan, saved.year, saved.myId));
        if (getLastLoadResult?.().status === 'recovered') gs.notify('バックアップから復旧しました。その後の未保存の変更は含まれません。', 'warn');
      } catch (error) {
        if (!loadIsStale()) {
          console.error('セーブデータの読み込みに失敗しました:', error);
          gs.notify('セーブデータを読み込めませんでした。再試行してください', 'warn');
        }
      }
    });
  };

  const app = { gs, sf, os, handleLoad };
  const hubProps = {
    state: { gs },
    flows: { sf, os },
    app,
  };

  if (gs.screen === 'hub') {
    return <HubShell {...hubProps} />;
  }

  return <AppScreenRouter app={app} />;
}
